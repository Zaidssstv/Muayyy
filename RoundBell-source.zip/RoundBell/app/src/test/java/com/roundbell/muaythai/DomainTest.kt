package com.roundbell.muaythai

import com.roundbell.muaythai.data.model.Category
import com.roundbell.muaythai.data.model.Difficulty
import com.roundbell.muaythai.data.model.Equipment
import com.roundbell.muaythai.data.model.Goal
import com.roundbell.muaythai.data.model.HistoryEntry
import com.roundbell.muaythai.data.model.Intensity
import com.roundbell.muaythai.data.model.LoggedExercise
import com.roundbell.muaythai.data.model.Section
import com.roundbell.muaythai.data.model.SectionType
import com.roundbell.muaythai.data.model.TrainingStyle
import com.roundbell.muaythai.data.model.WorkItem
import com.roundbell.muaythai.data.model.Workout
import com.roundbell.muaythai.data.model.WorkoutCodec
import com.roundbell.muaythai.data.model.encodeLog
import com.roundbell.muaythai.data.model.loggedExercises
import com.roundbell.muaythai.data.seed.ExerciseSeed
import com.roundbell.muaythai.domain.GeneratorParams
import com.roundbell.muaythai.domain.Stats
import com.roundbell.muaythai.domain.WorkoutGenerator
import com.roundbell.muaythai.domain.WorkoutMath
import com.roundbell.muaythai.domain.formatClock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

class DomainTest {
    private fun item(name: String, sec: Int, rest: Int = 0) =
        WorkItem(exerciseId = name.lowercase(), name = name, category = Category.BOXING, seconds = sec, restSec = rest)

    private val sample = Workout(
        name = "Test",
        sections = listOf(
            Section(type = SectionType.WARMUP, title = "Warm-up", items = listOf(item("Rope", 60))),
            Section(type = SectionType.ROUND, title = "Round 1", sets = 2, restAfterSec = 60,
                items = listOf(item("Jab", 30, 10), item("Cross", 30, 10))),
            Section(type = SectionType.COOLDOWN, title = "Cooldown", items = emptyList())
        )
    )

    @Test fun flattenMergesRestsAndDropsTrailingRest() {
        val steps = WorkoutMath.flatten(sample)
        assertFalse(steps.last().isRest)
        // no two consecutive rests
        assertTrue(steps.zipWithNext().none { (a, b) -> a.isRest && b.isRest })
        // Cross rest (10) + round rest (60) merged into one 70s rest between sets
        assertTrue(steps.any { it.isRest && it.seconds == 70 })
        assertEquals(5, steps.count { !it.isRest })
        assertEquals(listOf(0, 1, 1, 2, 2), steps.filter { !it.isRest }.map { it.round })
    }

    @Test fun summaryCountsRoundsAndTime() {
        val s = WorkoutMath.summary(sample, 70.0)
        assertEquals(2, s.rounds)
        assertEquals(60 + 4 * 30, s.workSec)
        assertEquals(s.workSec + s.restSec, s.totalSec)
        assertTrue(s.calories > 0)
    }

    @Test fun emptyWorkoutHasNoSteps() {
        assertTrue(WorkoutMath.flatten(Workout(sections = listOf(Section(type = SectionType.ROUND, title = "R")))).isEmpty())
    }

    @Test fun clockFormatting() {
        assertEquals("0:05", formatClock(5))
        assertEquals("1:30", formatClock(90))
        assertEquals("1:00:00", formatClock(3600))
    }

    @Test fun seedHasUniqueIdsAndAllCategories() {
        val all = ExerciseSeed.all
        assertTrue(all.size >= 90)
        assertEquals(all.size, all.map { it.id }.toSet().size)
        Category.entries.filter { it != Category.CUSTOM }.forEach { c -> assertTrue("missing $c", all.any { it.category == c }) }
    }

    @Test fun generatorRespectsDurationAndEquipment() {
        for (minutes in listOf(5, 10, 20, 45, 60)) for (style in TrainingStyle.entries) for (goal in Goal.entries) {
            val p = GeneratorParams(goal = goal, difficulty = Difficulty.INTERMEDIATE, minutes = minutes, style = style,
                equipment = setOf(Equipment.NONE), intensity = Intensity.HARD)
            val w = WorkoutGenerator.generate(p, ExerciseSeed.all, seed = 42L + minutes)
            val total = WorkoutMath.summary(w, 70.0).totalSec
            assertTrue("empty workout for $p", WorkoutMath.flatten(w).isNotEmpty())
            assertTrue("duration $total for $minutes min ($style/$goal)", total in (minutes * 60 * 0.7).toInt()..(minutes * 60 * 1.3).toInt())
            val ids = w.sections.flatMap { s -> s.items.map { it.exerciseId } }.toSet()
            val needEquip = ExerciseSeed.all.filter { it.id in ids }.flatMap { it.equipment }.filter { it != Equipment.NONE }
            assertTrue("equipment leak $needEquip", needEquip.isEmpty())
        }
    }

    @Test fun codecRoundTrip() {
        val decoded = WorkoutCodec.decode(WorkoutCodec.encode(sample.copy(notes = "note", intensity = Intensity.MAXIMUM)))
        assertEquals("Test", decoded.name)
        assertEquals("note", decoded.notes)
        assertEquals(Intensity.MAXIMUM, decoded.intensity)
        assertEquals(sample.sections.map { it.items.map { i -> i.name to i.seconds } }, decoded.sections.map { it.items.map { i -> i.name to i.seconds } })
        assertEquals(WorkoutMath.flatten(sample).size, WorkoutMath.flatten(decoded).size)
    }

    private fun entry(daysAgo: Long, sec: Int = 600, today: LocalDate) = HistoryEntry(
        workoutId = null, workoutName = "W", startedAt = 0,
        finishedAt = today.minusDays(daysAgo).atTime(12, 0).atZone(ZoneId.of("UTC")).toInstant().toEpochMilli(),
        durationSec = sec, plannedSec = sec, workSec = sec, roundsCompleted = 3, totalRounds = 3,
        exercisesCompleted = 1, totalExercises = 1, goal = Goal.GENERAL, style = TrainingStyle.MIXED,
        intensity = Intensity.MODERATE, calories = 100, completionPct = 100,
        exerciseLog = encodeLog(listOf(LoggedExercise("Jab", Category.BOXING, 30))), workoutJson = "{}"
    )

    @Test fun statsStreaksAndLog() {
        val today = LocalDate.of(2026, 9, 30)
        val list = listOf(entry(0, today = today), entry(1, today = today), entry(2, today = today), entry(5, today = today))
        val z = ZoneId.of("UTC")
        assertEquals(3, Stats.currentStreak(list, today, z))
        assertEquals(3, Stats.longestStreak(list, z))
        assertEquals(0, Stats.currentStreak(emptyList(), today, z))
        assertEquals(7, Stats.last7Days(list, today, z).size)
        assertEquals(listOf(LoggedExercise("Jab", Category.BOXING, 30)), list.first().loggedExercises())
        assertEquals(Category.BOXING, Stats.byCategory(list).first().first)
    }
}
