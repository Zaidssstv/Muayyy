package com.roundbell.muaythai.data.model

import java.util.UUID

fun newUid(): String = UUID.randomUUID().toString().take(8)

data class WorkItem(
    val uid: String = newUid(),
    val exerciseId: String,
    val name: String,
    val category: Category,
    val seconds: Int,
    val reps: Int? = null,
    val restSec: Int = 0,
    val note: String = ""
)

data class Section(
    val uid: String = newUid(),
    val type: SectionType,
    val title: String,
    val items: List<WorkItem> = emptyList(),
    val sets: Int = 1,
    val restAfterSec: Int = 0
)

data class Workout(
    val id: Long = 0,
    val name: String = "My Workout",
    val notes: String = "",
    val goal: Goal = Goal.GENERAL,
    val difficulty: Difficulty = Difficulty.BEGINNER,
    val intensity: Intensity = Intensity.MODERATE,
    val style: TrainingStyle = TrainingStyle.MIXED,
    val sections: List<Section> = emptyList(),
    val isFavorite: Boolean = false,
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
    val lastUsedAt: Long? = null
)

fun Exercise.toWorkItem(seconds: Int = defaultSeconds, restSec: Int = 0) = WorkItem(
    exerciseId = id, name = name, category = category, seconds = seconds, restSec = restSec
)
