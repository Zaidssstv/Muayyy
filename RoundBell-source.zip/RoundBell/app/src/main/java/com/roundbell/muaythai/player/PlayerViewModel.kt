package com.roundbell.muaythai.player

import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.roundbell.muaythai.AppContainer
import com.roundbell.muaythai.data.model.HistoryEntry
import com.roundbell.muaythai.data.model.LoggedExercise
import com.roundbell.muaythai.data.model.Workout
import com.roundbell.muaythai.data.model.WorkoutCodec
import com.roundbell.muaythai.data.model.Category
import com.roundbell.muaythai.data.model.encodeLog
import com.roundbell.muaythai.data.prefs.AppSettings
import com.roundbell.muaythai.domain.Step
import com.roundbell.muaythai.domain.WorkoutMath
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.math.roundToInt

data class PlayerUi(
    val loaded: Boolean = false,
    val missing: Boolean = false,
    val workoutName: String = "",
    val steps: List<Step> = emptyList(),
    val index: Int = 0,
    val remainingMs: Long = 0,
    val running: Boolean = false,
    val elapsedMs: Long = 0,
    val totalRounds: Int = 0,
    val finished: Boolean = false,
    val result: HistoryEntry? = null,
    val keepScreenOn: Boolean = true
) {
    val step: Step? get() = steps.getOrNull(index)
    val next: Step? get() = steps.getOrNull(index + 1)
    val nextExercise: Step? get() = steps.drop(index + 1).firstOrNull { !it.isRest }
    val remainingWorkoutMs: Long get() = remainingMs.coerceAtLeast(0) + steps.drop(index + 1).sumOf { it.seconds * 1000L }
    val stepProgress: Float get() = step?.let { 1f - remainingMs.toFloat() / (it.seconds * 1000f) }?.coerceIn(0f, 1f) ?: 0f
    val workoutProgress: Float get() {
        val total = steps.sumOf { it.seconds * 1000L }.coerceAtLeast(1)
        return ((total - remainingWorkoutMs).toFloat() / total).coerceIn(0f, 1f)
    }
    val exerciseNumber: Int get() = steps.take(index + 1).count { !it.isRest && it.exerciseId != GET_READY }
    val exerciseCount: Int get() = steps.count { !it.isRest && it.exerciseId != GET_READY }
    val currentRound: Int get() = steps.take(index + 1).lastOrNull { it.round > 0 }?.round ?: 0

    companion object { const val GET_READY = "__get_ready" }
}

class PlayerViewModel(private val c: AppContainer) : ViewModel() {
    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui

    private var workout: Workout? = null
    private var startedAt = 0L
    private var worked = LongArray(0)
    private var settings = AppSettings()
    private var weightKg = 70.0
    private var loop: Job? = null
    private var lastPersist = 0L

    init {
        viewModelScope.launch {
            settings = c.settings.settings.first()
            weightKg = c.settings.profile.first().weightForCalories
            if (settings.voice) c.cues.prepareVoice()
            val snap = c.session.load()
            if (snap == null) { _ui.value = PlayerUi(loaded = true, missing = true); return@launch }
            workout = snap.workout
            val prep = Step("Get ready", PlayerUi.GET_READY, settings.countdownSeconds.coerceIn(3, 30), true, null,
                "Get ready", null, 0, null)
            val steps = listOf(prep) + WorkoutMath.flatten(snap.workout)
            if (steps.size <= 1) { _ui.value = PlayerUi(loaded = true, missing = true); c.session.clear(); return@launch }
            startedAt = snap.startedAt
            worked = LongArray(steps.size).also { arr -> snap.workedMs.copyInto(arr, 0, 0, min(arr.size, snap.workedMs.size)) }
            val fresh = snap.remainingMs < 0
            val idx = snap.index.coerceIn(0, steps.lastIndex)
            _ui.value = PlayerUi(
                loaded = true, workoutName = snap.workout.name, steps = steps, index = idx,
                remainingMs = if (fresh) steps[idx].seconds * 1000L else snap.remainingMs.coerceAtLeast(1000),
                running = fresh, // resumed sessions start paused so nothing is lost
                elapsedMs = snap.elapsedMs, totalRounds = WorkoutMath.totalRounds(snap.workout),
                keepScreenOn = settings.keepScreenOn
            )
            if (fresh) announce(steps[idx], steps.getOrNull(idx + 1), first = true)
            persist(force = true)
            startLoop()
        }
        // keep settings live (e.g. user toggles voice mid-session from another screen)
        viewModelScope.launch { c.settings.settings.collect { settings = it } }
    }

    private fun startLoop() {
        loop?.cancel()
        loop = viewModelScope.launch {
            var last = SystemClock.elapsedRealtime()
            while (isActive) {
                delay(100)
                val now = SystemClock.elapsedRealtime()
                val dt = now - last
                last = now
                tick(dt)
            }
        }
    }

    private fun tick(dt: Long) {
        val s = _ui.value
        if (!s.running || s.finished) return
        val step = s.step ?: return
        val prevSec = ceilSec(s.remainingMs)
        val rem = s.remainingMs - dt
        if (!step.isRest) worked[s.index] += min(dt, s.remainingMs.coerceAtLeast(0))
        _ui.value = s.copy(remainingMs = rem, elapsedMs = s.elapsedMs + dt)
        if (rem <= 0) {
            goTo(s.index + 1)
        } else {
            val sec = ceilSec(rem)
            if (sec != prevSec) onSecond(sec, step)
            persist()
        }
    }

    private fun ceilSec(ms: Long) = ((ms + 999) / 1000).toInt()

    private fun onSecond(sec: Int, step: Step) {
        val cd = min(3, settings.countdownSeconds)
        if (sec in 1..cd) {
            if (settings.countdownSounds) c.cues.countdownBeep()
            if (settings.haptics) c.cues.vibrate(60)
            if (settings.voice && step.isRest) c.cues.speak(sec.toString())
        }
        if (sec == 10 && !step.isRest && step.seconds >= 25 && settings.voice) c.cues.speak("10 seconds")
        if (sec == 10 && step.isRest && step.seconds >= 20) {
            val nx = _ui.value.next
            if (settings.voice && nx != null) c.cues.speak("Get ready. Next: ${nx.label}")
        }
    }

    private fun announce(step: Step, next: Step?, first: Boolean = false) {
        if (settings.haptics) c.cues.vibrate(if (step.isRest) 200 else 350)
        if (step.isRest) {
            if (settings.restSounds && !first) c.cues.restBeep()
            if (settings.voice) {
                if (step.exerciseId == PlayerUi.GET_READY) c.cues.speak("Get ready. First: ${next?.label ?: ""}")
                else c.cues.speak("Rest. Next: ${next?.label ?: ""}")
            }
        } else {
            if (settings.transitionSounds) c.cues.workBeep()
            if (settings.voice) {
                val reps = step.reps?.let { ", $it reps" } ?: ""
                val prev = _ui.value.steps.getOrNull(_ui.value.index - 1)
                c.cues.speak(if (prev?.isRest != false) "Go! ${step.label}$reps" else "${step.label}$reps")
            }
        }
    }

    private fun goTo(target: Int) {
        val s = _ui.value
        if (target > s.steps.lastIndex) { finish(); return }
        val t = target.coerceAtLeast(0)
        _ui.value = s.copy(index = t, remainingMs = s.steps[t].seconds * 1000L)
        announce(s.steps[t], s.steps.getOrNull(t + 1))
        persist(force = true)
    }

    fun togglePause() {
        val s = _ui.value
        if (s.finished || s.steps.isEmpty()) return
        _ui.value = s.copy(running = !s.running)
        if (settings.haptics) c.cues.vibrate(40)
        persist(force = true)
    }

    fun skip() { if (!_ui.value.finished) goTo(_ui.value.index + 1) }

    fun previous() {
        val s = _ui.value
        val step = s.step ?: return
        val spent = step.seconds * 1000L - s.remainingMs
        if (spent > 3000 || s.index == 0) {
            _ui.value = s.copy(remainingMs = step.seconds * 1000L); persist(force = true)
        } else goTo(s.index - 1)
    }

    /** End now. If [save] is true, a (possibly partial) history entry is recorded. */
    fun end(save: Boolean) {
        if (save) finish() else {
            loop?.cancel()
            c.session.clear()
            _ui.value = _ui.value.copy(running = false, finished = true, result = null)
        }
    }

    private fun finish() {
        val s = _ui.value
        if (s.finished) return
        loop?.cancel()
        _ui.value = s.copy(running = false, finished = true, remainingMs = 0)
        val w = workout ?: return
        if (settings.transitionSounds) c.cues.finishBeep()
        if (settings.voice) c.cues.speak("Workout complete. Great work!")
        if (settings.haptics) c.cues.vibrate(600)

        val steps = s.steps
        val workIdx = steps.indices.filter { !steps[it].isRest }
        val plannedWorkMs = workIdx.sumOf { steps[it].seconds * 1000L }.coerceAtLeast(1)
        val workedMs = workIdx.sumOf { worked[it] }
        val done = workIdx.filter { worked[it] >= steps[it].seconds * 1000L * 0.8 }
        val log = done.map { LoggedExercise(steps[it].label, steps[it].category ?: Category.CUSTOM, (worked[it] / 1000).toInt()) }
        val roundsDone = steps.filter { it.round > 0 }.map { it.round }.distinct().count { r ->
            val idx = workIdx.filter { steps[it].round == r }
            val planned = idx.sumOf { steps[it].seconds * 1000L }
            planned > 0 && idx.sumOf { worked[it] } >= planned * 0.6
        }
        val workKcal = workIdx.sumOf { WorkoutMath.caloriesFor(steps[it], worked[it] / 1000.0, w.intensity, weightKg) }
        // Rest time actually elapsed = total elapsed minus work time (rest MET).
        val restKcal = WorkoutMath.caloriesFor(steps.first(), (s.elapsedMs - workedMs).coerceAtLeast(0) / 1000.0, w.intensity, weightKg)
        val kcal = workKcal + restKcal
        val entry = HistoryEntry(
            workoutId = w.id.takeIf { it > 0 },
            workoutName = w.name,
            startedAt = startedAt,
            finishedAt = System.currentTimeMillis(),
            durationSec = (s.elapsedMs / 1000).toInt(),
            plannedSec = steps.drop(1).sumOf { it.seconds },
            workSec = (workedMs / 1000).toInt(),
            roundsCompleted = roundsDone,
            totalRounds = WorkoutMath.totalRounds(w),
            exercisesCompleted = done.size,
            totalExercises = workIdx.size,
            goal = w.goal, style = w.style, intensity = w.intensity,
            calories = kcal.roundToInt(),
            completionPct = ((workedMs * 100) / plannedWorkMs).toInt().coerceIn(0, 100),
            exerciseLog = encodeLog(log),
            workoutJson = WorkoutCodec.encode(w)
        )
        c.session.clear()
        viewModelScope.launch {
            if (workedMs >= 1000) {
                val id = c.repo.addHistory(entry)
                if (w.id > 0) c.repo.markWorkoutUsed(w.id)
                _ui.value = _ui.value.copy(result = entry.copy(id = id))
            } else {
                _ui.value = _ui.value.copy(result = null)
            }
        }
    }

    private fun persist(force: Boolean = false) {
        val s = _ui.value
        val w = workout ?: return
        if (s.finished) return
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastPersist < 1000) return
        lastPersist = now
        c.session.save(SessionSnapshot(w, s.index, s.remainingMs.coerceAtLeast(1), s.elapsedMs, startedAt, worked.copyOf()))
    }

    override fun onCleared() {
        // Leaving the player keeps the session (paused) so the user can continue from Home.
        persist(force = true)
        super.onCleared()
    }
}
