package com.roundbell.muaythai

import android.app.Application
import com.roundbell.muaythai.notify.Reminders
import kotlinx.coroutines.launch

class RoundBellApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        Reminders.createChannel(this)
        container.appScope.launch { container.repo.seed() }
    }
}
