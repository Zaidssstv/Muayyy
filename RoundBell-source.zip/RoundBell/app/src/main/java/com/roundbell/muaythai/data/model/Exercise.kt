package com.roundbell.muaythai.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single exercise/technique. [equipment] lists equipment that is REQUIRED
 * (empty = bodyweight). [mediaUri] is reserved for future video/animation assets.
 */
@Entity(tableName = "exercises")
data class Exercise(
    @PrimaryKey val id: String,
    val name: String,
    val category: Category,
    val difficulty: Difficulty,
    val description: String,
    val steps: List<String>,
    val muscles: List<String>,
    val equipment: List<Equipment>,
    val purpose: String,
    val recommended: String,
    val defaultSeconds: Int,
    val defaultReps: Int?,
    val variations: List<String>,
    val safety: String?,
    val isFavorite: Boolean = false,
    val isCustom: Boolean = false,
    val mediaUri: String? = null
)
