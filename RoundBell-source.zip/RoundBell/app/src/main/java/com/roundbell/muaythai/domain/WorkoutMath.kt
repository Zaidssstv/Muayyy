package com.roundbell.muaythai.domain

import com.roundbell.muaythai.data.model.Category
import com.roundbell.muaythai.data.model.Intensity
import com.roundbell.muaythai.data.model.SectionType
import com.roundbell.muaythai.data.model.Workout
import kotlin.math.roundToInt

/** One timed step of a flattened workout, as executed by the player. */
data class Step(
    val label: String,
    val exerciseId: String?,
    val seconds: Int,
    val isRest: Boolean,
    val reps: Int?,
    val sectionTitle: String,
    val sectionType: SectionType?,
    val round: Int,
    val category: Category?,
    val note: String = ""
)

data class WorkoutSummary(
    val totalSec: Int, val workSec: Int, val restSec: Int,
    val exercises: Int, val rounds: Int, val calories: Int
)

object WorkoutMath {

    fun flatten(w: Workout): List<Step> {
        val out = mutableListOf<Step>()
        var round = 0
        for (s in w.sections) {
            if (s.items.isEmpty()) continue
            val sets = s.sets.coerceAtLeast(1)
            for (setIdx in 0 until sets) {
                val r = if (s.type == SectionType.ROUND) { round += 1; round } else 0
                val title = if (sets > 1) "${s.title} · ${setIdx + 1}/$sets" else s.title
                for (item in s.items) {
                    out += Step(item.name, item.exerciseId, item.seconds.coerceAtLeast(1), false, item.reps,
                        title, s.type, r, item.category, item.note)
                    if (item.restSec > 0) out += rest(item.restSec, title, s.type, r)
                }
                if (s.restAfterSec > 0) out += rest(s.restAfterSec, title, s.type, r)
            }
        }
        // merge adjacent rests and drop trailing rests
        val merged = mutableListOf<Step>()
        for (st in out) {
            val last = merged.lastOrNull()
            if (st.isRest && last != null && last.isRest) merged[merged.lastIndex] = last.copy(seconds = last.seconds + st.seconds)
            else if (st.isRest && last == null) continue
            else merged += st
        }
        while (merged.isNotEmpty() && merged.last().isRest) merged.removeAt(merged.lastIndex)
        return merged
    }

    private fun rest(sec: Int, title: String, type: SectionType, r: Int) =
        Step("Rest", null, sec, true, null, title, type, r, null)

    fun totalRounds(w: Workout): Int =
        w.sections.filter { it.type == SectionType.ROUND && it.items.isNotEmpty() }.sumOf { it.sets.coerceAtLeast(1) }

    fun met(step: Step, intensity: Intensity): Double = when {
        step.isRest -> 2.0
        step.sectionType == SectionType.COOLDOWN -> 2.5
        step.sectionType == SectionType.WARMUP || step.category == Category.MOBILITY -> 3.5
        step.category == Category.CONDITIONING -> intensity.met + 1.0
        else -> intensity.met
    }

    fun caloriesFor(step: Step, seconds: Double, intensity: Intensity, weightKg: Double): Double =
        met(step, intensity) * weightKg * seconds / 3600.0

    fun summary(w: Workout, weightKg: Double): WorkoutSummary {
        val steps = flatten(w)
        val work = steps.filter { !it.isRest }.sumOf { it.seconds }
        val rest = steps.filter { it.isRest }.sumOf { it.seconds }
        val kcal = steps.sumOf { caloriesFor(it, it.seconds.toDouble(), w.intensity, weightKg) }
        return WorkoutSummary(work + rest, work, rest, steps.count { !it.isRest }, totalRounds(w), kcal.roundToInt())
    }
}

fun formatClock(totalSec: Int): String {
    val s = totalSec.coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun formatMinutes(totalSec: Int): String {
    val m = (totalSec + 30) / 60
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "$m min"
}
