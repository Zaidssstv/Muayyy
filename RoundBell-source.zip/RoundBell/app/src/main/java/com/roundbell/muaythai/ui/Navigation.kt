package com.roundbell.muaythai.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.roundbell.muaythai.AppContainer
import com.roundbell.muaythai.R
import com.roundbell.muaythai.player.PlayerViewModel
import com.roundbell.muaythai.ui.screens.BuilderScreen
import com.roundbell.muaythai.ui.screens.ExerciseDetailScreen
import com.roundbell.muaythai.ui.screens.ExercisesScreen
import com.roundbell.muaythai.ui.screens.GeneratorScreen
import com.roundbell.muaythai.ui.screens.HistoryDetailScreen
import com.roundbell.muaythai.ui.screens.HomeScreen
import com.roundbell.muaythai.ui.screens.PlayerScreen
import com.roundbell.muaythai.ui.screens.ProfileScreen
import com.roundbell.muaythai.ui.screens.ProgressScreen
import com.roundbell.muaythai.ui.screens.WorkoutsScreen

object Routes {
    const val HOME = "home"
    const val WORKOUTS = "workouts"
    const val EXERCISES = "exercises"
    const val PROGRESS = "progress"
    const val PROFILE = "profile"
    const val GENERATOR = "generator"
    const val PLAYER = "player"
    fun exercise(id: String) = "exercise/$id"
    fun builder(id: Long) = "builder/$id"
    fun history(id: Long) = "history/$id"
}

private data class Tab(val route: String, val label: String, val icon: @Composable () -> Painter)

/** Navigation actions shared by all screens. */
class Nav(private val nav: NavHostController) {
    fun back() { nav.popBackStack() }
    fun exercise(id: String) = nav.navigate(Routes.exercise(id))
    fun builder(id: Long) = nav.navigate(Routes.builder(id))
    fun generator() = nav.navigate(Routes.GENERATOR)
    fun player() = nav.navigate(Routes.PLAYER) { launchSingleTop = true }
    fun history(id: Long) = nav.navigate(Routes.history(id))
    fun tab(route: String) = nav.navigate(route) {
        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true; restoreState = true
    }
    fun playerToHistory(id: Long) = nav.navigate(Routes.history(id)) { popUpTo(Routes.PLAYER) { inclusive = true } }
}

@Composable
fun RoundBellRoot(c: AppContainer) {
    val navController = rememberNavController()
    val nav = Nav(navController)
    val vm: AppViewModel = viewModel(factory = viewModelFactory { initializer { AppViewModel(c) } })
    val tabs = listOf(
        Tab(Routes.HOME, "Home") { rememberVectorPainter(Icons.Default.Home) },
        Tab(Routes.WORKOUTS, "Workouts") { painterResource(R.drawable.ic_dumbbell) },
        Tab(Routes.EXERCISES, "Exercises") { painterResource(R.drawable.ic_glove) },
        Tab(Routes.PROGRESS, "Progress") { painterResource(R.drawable.ic_chart) },
        Tab(Routes.PROFILE, "Profile") { rememberVectorPainter(Icons.Default.Person) }
    )
    val entry by navController.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val showBar = tabs.any { it.route == route }

    Scaffold(
        bottomBar = {
            if (showBar) NavigationBar {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route,
                        onClick = { nav.tab(t.route) },
                        icon = { Icon(t.icon(), contentDescription = null) },
                        label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                            indicatorColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
        }
    ) { pad ->
        NavHost(navController, startDestination = Routes.HOME, modifier = Modifier.padding(bottom = pad.calculateBottomPadding())) {
            composable(Routes.HOME) { HomeScreen(vm, nav) }
            composable(Routes.WORKOUTS) { WorkoutsScreen(vm, nav) }
            composable(Routes.EXERCISES) { ExercisesScreen(vm, nav) }
            composable(Routes.PROGRESS) { ProgressScreen(vm, nav) }
            composable(Routes.PROFILE) { ProfileScreen(vm) }
            composable(Routes.GENERATOR) { GeneratorScreen(vm, nav) }
            composable("exercise/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                ExerciseDetailScreen(vm, nav, e.arguments?.getString("id").orEmpty())
            }
            composable("builder/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                val id = e.arguments?.getLong("id") ?: 0L
                val bvm: BuilderViewModel = viewModel(
                    key = "builder_$id",
                    factory = viewModelFactory { initializer { BuilderViewModel(c, id) } }
                )
                BuilderScreen(vm, bvm, nav)
            }
            composable(Routes.PLAYER) {
                val pvm: PlayerViewModel = viewModel(factory = viewModelFactory { initializer { PlayerViewModel(c) } })
                PlayerScreen(pvm, nav)
            }
            composable("history/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                HistoryDetailScreen(vm, nav, e.arguments?.getLong("id") ?: 0L)
            }
        }
    }
}
