package com.roundbell.muaythai.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workouts")
data class WorkoutEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val notes: String,
    val json: String,
    val isFavorite: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val lastUsedAt: Long?
)

@Entity(tableName = "history")
data class HistoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workoutId: Long?,
    val workoutName: String,
    val startedAt: Long,
    val finishedAt: Long,
    val durationSec: Int,
    val plannedSec: Int,
    val workSec: Int,
    val roundsCompleted: Int,
    val totalRounds: Int,
    val exercisesCompleted: Int,
    val totalExercises: Int,
    val goal: Goal,
    val style: TrainingStyle,
    val intensity: Intensity,
    val calories: Int,
    val completionPct: Int,
    /** One line per completed exercise: name|CATEGORY|seconds */
    val exerciseLog: String,
    val workoutJson: String
)

data class LoggedExercise(val name: String, val category: Category, val seconds: Int)

fun HistoryEntry.loggedExercises(): List<LoggedExercise> =
    exerciseLog.lines().filter { it.isNotBlank() }.mapNotNull { line ->
        val p = line.split("|")
        if (p.size < 3) null
        else LoggedExercise(p[0], enumOr(p[1], Category.CUSTOM), p[2].toIntOrNull() ?: 0)
    }

fun encodeLog(list: List<LoggedExercise>): String =
    list.joinToString("\n") { "${it.name.replace("|", "/")}|${it.category.name}|${it.seconds}" }
