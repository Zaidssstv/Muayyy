package com.roundbell.muaythai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roundbell.muaythai.data.model.HistoryEntry
import com.roundbell.muaythai.data.model.WorkoutCodec
import com.roundbell.muaythai.data.model.loggedExercises
import com.roundbell.muaythai.domain.Stats
import com.roundbell.muaythai.domain.formatClock
import com.roundbell.muaythai.domain.formatMinutes
import com.roundbell.muaythai.ui.AppViewModel
import com.roundbell.muaythai.ui.Nav
import com.roundbell.muaythai.ui.components.BarChart
import com.roundbell.muaythai.ui.components.CategoryBadge
import com.roundbell.muaythai.ui.components.EmptyState
import com.roundbell.muaythai.ui.components.RbCard
import com.roundbell.muaythai.ui.components.SectionTitle
import com.roundbell.muaythai.ui.components.StatRow
import com.roundbell.muaythai.ui.components.StatTile
import java.text.DateFormat
import java.util.Date

internal fun formatDate(ms: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(vm: AppViewModel, nav: Nav) {
    val history by vm.history.collectAsStateWithLifecycle()
    var toDelete by rememberSaveable { mutableStateOf<Long?>(null) }

    Scaffold(topBar = { TopAppBar(title = { Text("Progress") }) }) { pad ->
        if (history.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                EmptyState("No training logged yet", "Finish your first workout and your stats, charts and records will appear here.") {
                    Button(onClick = { nav.generator() }) { Text("Generate a workout") }
                }
            }
            return@Scaffold
        }
        val week = remember(history) { Stats.thisWeek(history) }
        val month = remember(history) { Stats.thisMonth(history) }
        val all = remember(history) { Stats.summarize(history) }
        val streak = remember(history) { Stats.currentStreak(history) }
        val records = remember(history) { Stats.records(history) }
        val weekly = remember(history) { Stats.weeklyCounts(history) }
        val days = remember(history) { Stats.last7Days(history) }
        val cats = remember(history) { Stats.byCategory(history) }

        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
            item {
                SectionTitle("Overview")
                StatRow {
                    StatTile(week.workouts.toString(), "This week", Modifier.weight(1f))
                    StatTile(month.workouts.toString(), "This month", Modifier.weight(1f))
                    StatTile("$streak d", "Streak", Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                StatRow {
                    StatTile(all.workouts.toString(), "Total workouts", Modifier.weight(1f))
                    StatTile(formatMinutes(all.seconds), "Total time", Modifier.weight(1f))
                    StatTile(all.rounds.toString(), "Rounds done", Modifier.weight(1f))
                }
                SectionTitle("Minutes · last 7 days")
                RbCard { BarChart(days, Modifier.padding(12.dp), unit = " min") }
                SectionTitle("Workouts per week")
                RbCard { BarChart(weekly, Modifier.padding(12.dp)) }
                if (cats.isNotEmpty()) {
                    SectionTitle("Training by category")
                    RbCard {
                        Column(Modifier.padding(12.dp)) {
                            val max = cats.maxOf { it.second }.coerceAtLeast(1)
                            cats.forEach { (cat, sec) ->
                                Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    CategoryBadge(cat, size = 30)
                                    Spacer(Modifier.width(8.dp))
                                    Column(Modifier.weight(1f)) {
                                        Row { Text(cat.short, Modifier.weight(1f)); Text(formatMinutes(sec), style = MaterialTheme.typography.labelMedium) }
                                        LinearProgressIndicator(progress = { sec.toFloat() / max },
                                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape))
                                    }
                                }
                            }
                        }
                    }
                }
                SectionTitle("Personal records")
                StatRow {
                    StatTile(formatMinutes(records.longestWorkoutSec), "Longest session", Modifier.weight(1f))
                    StatTile("${records.mostRounds}", "Most rounds", Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                StatRow {
                    StatTile("~${records.mostCalories}", "Most kcal (est.)", Modifier.weight(1f))
                    StatTile("${records.longestStreak} d", "Best streak", Modifier.weight(1f))
                }
                SectionTitle("History")
            }
            items(history, key = { it.id }) { h ->
                HistoryRow(h, onClick = { nav.history(h.id) }, onDelete = { toDelete = h.id })
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (toDelete != null) AlertDialog(
        onDismissRequest = { toDelete = null },
        title = { Text("Delete this entry?") },
        text = { Text("It will be removed from your history and stats.") },
        confirmButton = { TextButton(onClick = { toDelete?.let { vm.deleteHistory(it) }; toDelete = null }) { Text("Delete") } },
        dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
    )
}

@Composable
private fun HistoryRow(h: HistoryEntry, onClick: () -> Unit, onDelete: () -> Unit) {
    RbCard(Modifier.padding(vertical = 4.dp), onClick = onClick) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(h.workoutName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(formatDate(h.finishedAt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${formatMinutes(h.durationSec)} · ${h.roundsCompleted} rounds · ~${h.calories} kcal · ${h.completionPct}%",
                    style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete ${h.workoutName} entry") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryDetailScreen(vm: AppViewModel, nav: Nav, id: Long) {
    val history by vm.history.collectAsStateWithLifecycle()
    val h = history.firstOrNull { it.id == id }
    Scaffold(topBar = {
        TopAppBar(title = { Text("Workout details") },
            navigationIcon = { IconButton(onClick = { nav.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } })
    }) { pad ->
        if (h == null) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                EmptyState("Entry not found", "This workout may have been deleted.")
            }
            return@Scaffold
        }
        val log = remember(h) { h.loggedExercises() }
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
            item {
                Text(h.workoutName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(formatDate(h.finishedAt), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                StatRow {
                    StatTile(formatClock(h.durationSec), "Duration", Modifier.weight(1f))
                    StatTile("${h.roundsCompleted}/${h.totalRounds}", "Rounds", Modifier.weight(1f))
                    StatTile("${h.completionPct}%", "Completed", Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                StatRow {
                    StatTile("~${h.calories}", "kcal (est.)", Modifier.weight(1f))
                    StatTile("${h.exercisesCompleted}/${h.totalExercises}", "Exercises", Modifier.weight(1f))
                    StatTile(formatClock(h.workSec), "Work time", Modifier.weight(1f))
                }
                SectionTitle("Session")
                Text("Type: ${h.style.label} · Goal: ${h.goal.label}")
                Text("Intensity: ${h.intensity.label}")
                Text("Planned: ${formatClock(h.plannedSec)}")
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        runCatching { WorkoutCodec.decode(h.workoutJson) }.getOrNull()?.let { vm.startWorkout(it.copy(id = h.workoutId ?: 0L)); nav.player() }
                    }, Modifier.weight(1f).height(52.dp)) { Text("Repeat") }
                    OutlinedButton(onClick = {
                        runCatching { WorkoutCodec.decode(h.workoutJson) }.getOrNull()?.let { vm.setDraft(it.copy(id = 0)); nav.builder(-1) }
                    }, Modifier.weight(1f).height(52.dp)) { Text("Edit as new") }
                }
                SectionTitle("Completed exercises (${log.size})")
                if (log.isEmpty()) Text("No exercise was completed in this session.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(log.size) { i ->
                val e = log[i]
                Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    CategoryBadge(e.category, size = 32)
                    Spacer(Modifier.width(10.dp))
                    Text(e.name, Modifier.weight(1f))
                    Text(formatClock(e.seconds), style = MaterialTheme.typography.labelLarge)
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
