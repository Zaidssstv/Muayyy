package com.roundbell.muaythai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roundbell.muaythai.R
import com.roundbell.muaythai.domain.Stats
import com.roundbell.muaythai.domain.WorkoutMath
import com.roundbell.muaythai.domain.formatMinutes
import com.roundbell.muaythai.ui.AppViewModel
import com.roundbell.muaythai.ui.Nav
import com.roundbell.muaythai.ui.components.RbCard
import com.roundbell.muaythai.ui.components.SectionTitle
import com.roundbell.muaythai.ui.components.StatRow
import com.roundbell.muaythai.ui.components.StatTile
import java.text.DateFormat
import java.time.LocalTime
import java.util.Date

@Composable
fun HomeScreen(vm: AppViewModel, nav: Nav) {
    val profile by vm.profile.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val workouts by vm.workouts.collectAsStateWithLifecycle()
    val suggested by vm.suggested.collectAsStateWithLifecycle()
    val active by vm.activeSession.collectAsStateWithLifecycle()

    val week = Stats.thisWeek(history)
    val all = Stats.summarize(history)
    val streak = Stats.currentStreak(history)
    val hour = LocalTime.now().hour
    val greet = when { hour < 12 -> "Good morning"; hour < 18 -> "Good afternoon"; else -> "Good evening" }

    Column(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars).verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(if (profile.name.isNotBlank()) "$greet, ${profile.name}" else greet,
            style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Ready to train?", style = MaterialTheme.typography.headlineLarge)

        if (active != null) {
            Spacer(Modifier.height(12.dp))
            RbCard(onClick = { nav.player() }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayArrow, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Continue workout", style = MaterialTheme.typography.titleMedium)
                        Text(active ?: "", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.quickWorkout()?.let { vm.startWorkout(it); nav.player() } },
            modifier = Modifier.fillMaxWidth().height(60.dp)
        ) {
            Icon(painterResource(R.drawable.ic_bolt), null); Spacer(Modifier.width(8.dp))
            Text("QUICK WORKOUT · 10 MIN")
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { nav.builder(0) }, Modifier.weight(1f).height(52.dp)) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Custom")
            }
            OutlinedButton(onClick = { nav.generator() }, Modifier.weight(1f).height(52.dp)) {
                Icon(painterResource(R.drawable.ic_bolt), null); Spacer(Modifier.width(4.dp)); Text("Generate")
            }
            OutlinedButton(onClick = { nav.tab(com.roundbell.muaythai.ui.Routes.EXERCISES) }, Modifier.weight(1f).height(52.dp)) {
                Icon(Icons.Default.Search, null); Spacer(Modifier.width(4.dp)); Text("Browse")
            }
        }

        suggested?.let { s ->
            val sum = WorkoutMath.summary(s, profile.weightForCalories)
            SectionTitle("Today's suggested workout")
            RbCard {
                Column(Modifier.padding(16.dp)) {
                    Text(s.name, style = MaterialTheme.typography.titleLarge)
                    Text("${formatMinutes(sum.totalSec)} · ${sum.exercises} exercises · ${sum.rounds} rounds · ~${sum.calories} kcal",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${s.difficulty.label} · ${s.intensity.label}", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.startWorkout(s); nav.player() }, Modifier.weight(1f).height(48.dp)) { Text("START") }
                        OutlinedButton(onClick = { vm.setDraft(s); nav.builder(-1) }, Modifier.weight(1f).height(48.dp)) { Text("Customize") }
                    }
                }
            }
        }

        SectionTitle("This week")
        StatRow {
            StatTile(week.workouts.toString(), "workouts", Modifier.weight(1f))
            StatTile((week.seconds / 60).toString(), "minutes", Modifier.weight(1f))
            StatTile(week.rounds.toString(), "rounds", Modifier.weight(1f))
            StatTile("%,d".format(week.calories), "est. kcal", Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        StatRow {
            StatTile("$streak day${if (streak == 1) "" else "s"}", "streak", Modifier.weight(1f), accent = MaterialTheme.colorScheme.secondary)
            StatTile(all.workouts.toString(), "total workouts", Modifier.weight(1f))
            StatTile(formatMinutes(all.seconds), "total time", Modifier.weight(1f))
        }

        history.firstOrNull()?.let { h ->
            SectionTitle("Recently completed")
            RbCard(onClick = { nav.history(h.id) }) {
                Column(Modifier.padding(16.dp)) {
                    Text(h.workoutName, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(h.finishedAt))} · ${formatMinutes(h.durationSec)} · ${h.completionPct}% complete",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        val favs = workouts.filter { it.isFavorite }
        if (favs.isNotEmpty()) {
            SectionTitle("Favorite workouts")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(favs, key = { it.id }) { w ->
                    val sum = WorkoutMath.summary(w, profile.weightForCalories)
                    RbCard(Modifier.width(220.dp), onClick = { vm.startWorkout(w); nav.player() }) {
                        Column(Modifier.padding(14.dp)) {
                            Text(w.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(formatMinutes(sum.totalSec), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlayArrow, null, tint = MaterialTheme.colorScheme.primary)
                                Text("Start", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("Estimated calories use your profile weight (or 70 kg if not set). They are estimates, not measurements.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.height(16.dp))
    }
}
