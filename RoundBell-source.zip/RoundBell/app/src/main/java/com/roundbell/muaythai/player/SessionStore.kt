package com.roundbell.muaythai.player

import android.content.Context
import com.roundbell.muaythai.data.model.Workout
import com.roundbell.muaythai.data.model.WorkoutCodec
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Snapshot of an in-progress workout, persisted so it survives backgrounding and process death. */
data class SessionSnapshot(
    val workout: Workout,
    val index: Int,
    /** -1 = not started yet */
    val remainingMs: Long,
    val elapsedMs: Long,
    val startedAt: Long,
    val workedMs: LongArray
)

class SessionStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("active_session", Context.MODE_PRIVATE)
    private val _activeName = MutableStateFlow(prefs.getString(KEY_NAME, null))
    /** Name of the active workout, or null when no workout is in progress. */
    val activeName: StateFlow<String?> = _activeName

    fun start(w: Workout) {
        save(SessionSnapshot(w, 0, -1, 0, System.currentTimeMillis(), LongArray(0)))
    }

    fun save(s: SessionSnapshot) {
        val o = JSONObject()
        o.put("workout", WorkoutCodec.encode(s.workout))
        o.put("workoutId", s.workout.id)
        o.put("index", s.index)
        o.put("remaining", s.remainingMs)
        o.put("elapsed", s.elapsedMs)
        o.put("startedAt", s.startedAt)
        o.put("worked", JSONArray().apply { s.workedMs.forEach { put(it) } })
        prefs.edit().putString(KEY, o.toString()).putString(KEY_NAME, s.workout.name).apply()
        if (_activeName.value != s.workout.name) _activeName.value = s.workout.name
    }

    fun load(): SessionSnapshot? {
        val raw = prefs.getString(KEY, null) ?: return null
        return runCatching {
            val o = JSONObject(raw)
            val w = WorkoutCodec.decode(o.getString("workout")).copy(id = o.optLong("workoutId", 0))
            val arr = o.optJSONArray("worked") ?: JSONArray()
            SessionSnapshot(
                w, o.optInt("index", 0), o.optLong("remaining", -1), o.optLong("elapsed", 0),
                o.optLong("startedAt", System.currentTimeMillis()),
                LongArray(arr.length()) { arr.optLong(it, 0) }
            )
        }.getOrNull()
    }

    fun clear() {
        prefs.edit().clear().apply()
        _activeName.value = null
    }

    private companion object {
        const val KEY = "session"
        const val KEY_NAME = "name"
    }
}
