package com.roundbell.muaythai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.roundbell.muaythai.data.model.ThemeMode

val Crimson = Color(0xFFD7263D)
val CrimsonDeep = Color(0xFF9E1B2C)
val Gold = Color(0xFFF2B134)
val RestGreen = Color(0xFF2FBF71)

private val Dark = darkColorScheme(
    primary = Crimson, onPrimary = Color.White,
    primaryContainer = CrimsonDeep, onPrimaryContainer = Color.White,
    secondary = Gold, onSecondary = Color.Black,
    secondaryContainer = Color(0xFF3A2E14), onSecondaryContainer = Gold,
    tertiary = RestGreen, onTertiary = Color.Black,
    background = Color(0xFF0F0F11), onBackground = Color.White,
    surface = Color(0xFF151518), onSurface = Color.White,
    surfaceVariant = Color(0xFF26262C), onSurfaceVariant = Color(0xFFC4C4CC),
    surfaceContainerLowest = Color(0xFF0B0B0D), surfaceContainerLow = Color(0xFF16161A),
    surfaceContainer = Color(0xFF1B1B20), surfaceContainerHigh = Color(0xFF232329),
    surfaceContainerHighest = Color(0xFF2C2C33),
    outline = Color(0xFF5A5A63), outlineVariant = Color(0xFF34343B),
    error = Color(0xFFFF6B6B), onError = Color.Black
)

private val Light = lightColorScheme(
    primary = CrimsonDeep, onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDADC), onPrimaryContainer = Color(0xFF410008),
    secondary = Color(0xFF8A5A00), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE3B0), onSecondaryContainer = Color(0xFF2B1B00),
    tertiary = Color(0xFF14804A), onTertiary = Color.White,
    background = Color(0xFFF7F4F4), onBackground = Color(0xFF151518),
    surface = Color.White, onSurface = Color(0xFF151518),
    surfaceVariant = Color(0xFFEDE6E7), onSurfaceVariant = Color(0xFF4A4448),
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFF9F5F5),
    surfaceContainer = Color(0xFFF2EDED), surfaceContainerHigh = Color(0xFFECE6E6),
    surfaceContainerHighest = Color(0xFFE6DFE0)
)

private val base = Typography()
private val Type = Typography(
    displayLarge = base.displayLarge.copy(fontWeight = FontWeight.Black),
    displayMedium = base.displayMedium.copy(fontWeight = FontWeight.Black),
    headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.ExtraBold),
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
    headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.Bold),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Bold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
)

val TimerStyle = TextStyle(fontSize = 96.sp, fontWeight = FontWeight.Black, letterSpacing = (-2).sp)

@Composable
fun RoundBellTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) { ThemeMode.DARK -> true; ThemeMode.LIGHT -> false; ThemeMode.SYSTEM -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = Type, content = content)
}
