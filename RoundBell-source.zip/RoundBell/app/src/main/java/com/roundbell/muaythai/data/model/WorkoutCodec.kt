package com.roundbell.muaythai.data.model

import org.json.JSONArray
import org.json.JSONObject

/** Portable JSON format used for storage, sharing and import. */
object WorkoutCodec {
    const val FORMAT = "roundbell-workout-v1"

    fun encode(w: Workout): String {
        val o = JSONObject()
        o.put("format", FORMAT)
        o.put("name", w.name)
        o.put("notes", w.notes)
        o.put("goal", w.goal.name)
        o.put("difficulty", w.difficulty.name)
        o.put("intensity", w.intensity.name)
        o.put("style", w.style.name)
        val secs = JSONArray()
        w.sections.forEach { s ->
            val so = JSONObject()
            so.put("type", s.type.name)
            so.put("title", s.title)
            so.put("sets", s.sets)
            so.put("restAfter", s.restAfterSec)
            val items = JSONArray()
            s.items.forEach { i ->
                val io = JSONObject()
                io.put("ex", i.exerciseId)
                io.put("name", i.name)
                io.put("cat", i.category.name)
                io.put("sec", i.seconds)
                i.reps?.let { io.put("reps", it) }
                io.put("rest", i.restSec)
                io.put("note", i.note)
                items.put(io)
            }
            so.put("items", items)
            secs.put(so)
        }
        o.put("sections", secs)
        return o.toString()
    }

    fun decode(json: String): Workout {
        val o = JSONObject(json.trim())
        val secs = o.optJSONArray("sections") ?: JSONArray()
        val sections = (0 until secs.length()).map { si ->
            val so = secs.getJSONObject(si)
            val arr = so.optJSONArray("items") ?: JSONArray()
            Section(
                type = enumOr(so.optString("type"), SectionType.ROUND),
                title = so.optString("title", "Round"),
                sets = so.optInt("sets", 1).coerceIn(1, 50),
                restAfterSec = so.optInt("restAfter", 0).coerceIn(0, 3600),
                items = (0 until arr.length()).map { ii ->
                    val io = arr.getJSONObject(ii)
                    WorkItem(
                        exerciseId = io.optString("ex", "custom"),
                        name = io.optString("name", "Exercise"),
                        category = enumOr(io.optString("cat"), Category.CUSTOM),
                        seconds = io.optInt("sec", 30).coerceIn(1, 3600),
                        reps = if (io.has("reps")) io.optInt("reps").takeIf { it > 0 } else null,
                        restSec = io.optInt("rest", 0).coerceIn(0, 3600),
                        note = io.optString("note", "")
                    )
                }
            )
        }
        return Workout(
            name = o.optString("name", "Imported workout").ifBlank { "Imported workout" },
            notes = o.optString("notes", ""),
            goal = enumOr(o.optString("goal"), Goal.GENERAL),
            difficulty = enumOr(o.optString("difficulty"), Difficulty.BEGINNER),
            intensity = enumOr(o.optString("intensity"), Intensity.MODERATE),
            style = enumOr(o.optString("style"), TrainingStyle.MIXED),
            sections = sections
        )
    }
}
