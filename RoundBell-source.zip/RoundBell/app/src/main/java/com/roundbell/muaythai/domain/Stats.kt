package com.roundbell.muaythai.domain

import com.roundbell.muaythai.data.model.Category
import com.roundbell.muaythai.data.model.HistoryEntry
import com.roundbell.muaythai.data.model.loggedExercises
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale

data class PeriodSummary(val workouts: Int, val seconds: Int, val rounds: Int, val calories: Int)

data class PersonalRecords(
    val longestWorkoutSec: Int, val mostCalories: Int, val mostRounds: Int, val longestStreak: Int
)

/** All statistics are computed from real stored history — nothing is hardcoded. */
object Stats {
    private fun day(ms: Long, zone: ZoneId): LocalDate = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()

    fun summarize(list: List<HistoryEntry>) = PeriodSummary(
        list.size, list.sumOf { it.durationSec }, list.sumOf { it.roundsCompleted }, list.sumOf { it.calories }
    )

    fun thisWeek(list: List<HistoryEntry>, today: LocalDate = LocalDate.now(), zone: ZoneId = ZoneId.systemDefault()): PeriodSummary {
        val start = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        return summarize(list.filter { !day(it.finishedAt, zone).isBefore(start) && !day(it.finishedAt, zone).isAfter(today) })
    }

    fun thisMonth(list: List<HistoryEntry>, today: LocalDate = LocalDate.now(), zone: ZoneId = ZoneId.systemDefault()): PeriodSummary =
        summarize(list.filter { val d = day(it.finishedAt, zone); d.year == today.year && d.month == today.month })

    /** Consecutive days with training, ending today (or yesterday if not trained yet today). */
    fun currentStreak(list: List<HistoryEntry>, today: LocalDate = LocalDate.now(), zone: ZoneId = ZoneId.systemDefault()): Int {
        val days = list.map { day(it.finishedAt, zone) }.toSet()
        var d = if (today in days) today else today.minusDays(1)
        var n = 0
        while (d in days) { n++; d = d.minusDays(1) }
        return n
    }

    fun longestStreak(list: List<HistoryEntry>, zone: ZoneId = ZoneId.systemDefault()): Int {
        val days = list.map { day(it.finishedAt, zone) }.distinct().sortedBy { it.toEpochDay() }
        var best = 0; var cur = 0; var prev: LocalDate? = null
        for (d in days) {
            cur = if (prev != null && prev.plusDays(1) == d) cur + 1 else 1
            best = maxOf(best, cur); prev = d
        }
        return best
    }

    /** Seconds trained per category (work time only). */
    fun byCategory(list: List<HistoryEntry>): List<Pair<Category, Int>> =
        list.flatMap { it.loggedExercises() }.groupBy { it.category }
            .mapValues { e -> e.value.sumOf { it.seconds } }
            .toList().sortedByDescending { it.second }

    /** Workouts per week for the last [weeks] weeks, oldest first. Label = week start "d/M". */
    fun weeklyCounts(list: List<HistoryEntry>, weeks: Int = 8, today: LocalDate = LocalDate.now(), zone: ZoneId = ZoneId.systemDefault()): List<Pair<String, Int>> {
        val thisMonday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        return (weeks - 1 downTo 0).map { w ->
            val start = thisMonday.minusWeeks(w.toLong())
            val end = start.plusDays(6)
            val c = list.count { val d = day(it.finishedAt, zone); !d.isBefore(start) && !d.isAfter(end) }
            "${start.dayOfMonth}/${start.monthValue}" to c
        }
    }

    /** Minutes trained on each of the last 7 days, oldest first. */
    fun last7Days(list: List<HistoryEntry>, today: LocalDate = LocalDate.now(), zone: ZoneId = ZoneId.systemDefault()): List<Pair<String, Int>> =
        (6 downTo 0).map { i ->
            val d = today.minusDays(i.toLong())
            val sec = list.filter { day(it.finishedAt, zone) == d }.sumOf { it.durationSec }
            d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).take(3) to (sec + 30) / 60
        }

    fun records(list: List<HistoryEntry>) = PersonalRecords(
        list.maxOfOrNull { it.durationSec } ?: 0,
        list.maxOfOrNull { it.calories } ?: 0,
        list.maxOfOrNull { it.roundsCompleted } ?: 0,
        longestStreak(list)
    )
}
