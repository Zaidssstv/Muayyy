package com.roundbell.muaythai.data.db

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.Update
import com.roundbell.muaythai.data.model.Equipment
import com.roundbell.muaythai.data.model.Exercise
import com.roundbell.muaythai.data.model.HistoryEntry
import com.roundbell.muaythai.data.model.WorkoutEntity
import kotlinx.coroutines.flow.Flow

class Converters {
    @TypeConverter fun fromStrings(v: List<String>): String = v.joinToString(SEP)
    @TypeConverter fun toStrings(v: String): List<String> = if (v.isEmpty()) emptyList() else v.split(SEP)
    @TypeConverter fun fromEquipment(v: List<Equipment>): String = v.joinToString(",") { it.name }
    @TypeConverter fun toEquipment(v: String): List<Equipment> =
        if (v.isBlank()) emptyList() else v.split(",").mapNotNull { runCatching { Equipment.valueOf(it) }.getOrNull() }

    companion object { private const val SEP = "\u001F" }
}

@Dao
interface ExerciseDao {
    @Query("SELECT * FROM exercises ORDER BY category, name")
    fun observeAll(): Flow<List<Exercise>>

    @Query("SELECT * FROM exercises")
    suspend fun all(): List<Exercise>

    @Query("SELECT * FROM exercises WHERE id = :id")
    suspend fun get(id: String): Exercise?

    @Query("SELECT * FROM exercises WHERE id = :id")
    fun observe(id: String): Flow<Exercise?>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllIgnore(list: List<Exercise>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: Exercise)

    @Query("UPDATE exercises SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: String, fav: Boolean)

    @Query("DELETE FROM exercises WHERE id = :id AND isCustom = 1")
    suspend fun deleteCustom(id: String)

    @Query("DELETE FROM exercises")
    suspend fun clear()
}

@Dao
interface WorkoutDao {
    @Query("SELECT * FROM workouts ORDER BY isFavorite DESC, updatedAt DESC")
    fun observeAll(): Flow<List<WorkoutEntity>>

    @Query("SELECT * FROM workouts WHERE id = :id")
    suspend fun get(id: Long): WorkoutEntity?

    @Insert suspend fun insert(w: WorkoutEntity): Long
    @Update suspend fun update(w: WorkoutEntity)

    @Query("UPDATE workouts SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: Long, fav: Boolean)

    @Query("UPDATE workouts SET lastUsedAt = :t WHERE id = :id")
    suspend fun markUsed(id: Long, t: Long)

    @Query("DELETE FROM workouts WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM workouts")
    suspend fun clear()
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY finishedAt DESC")
    fun observeAll(): Flow<List<HistoryEntry>>

    @Query("SELECT * FROM history WHERE id = :id")
    suspend fun get(id: Long): HistoryEntry?

    @Insert suspend fun insert(h: HistoryEntry): Long

    @Query("DELETE FROM history WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM history")
    suspend fun clear()
}

@Database(
    entities = [Exercise::class, WorkoutEntity::class, HistoryEntry::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun exerciseDao(): ExerciseDao
    abstract fun workoutDao(): WorkoutDao
    abstract fun historyDao(): HistoryDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "roundbell.db")
                .build().also { instance = it }
        }
    }
}
