package com.roundbell.muaythai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roundbell.muaythai.data.prefs.AppSettings
import com.roundbell.muaythai.ui.RoundBellRoot
import com.roundbell.muaythai.ui.theme.RoundBellTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as RoundBellApp).container
        setContent {
            val settings by container.settings.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
            RoundBellTheme(settings.themeMode) {
                RoundBellRoot(container)
            }
        }
    }
}
