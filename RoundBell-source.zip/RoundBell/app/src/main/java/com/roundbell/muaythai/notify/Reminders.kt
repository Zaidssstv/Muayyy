package com.roundbell.muaythai.notify

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.roundbell.muaythai.MainActivity
import com.roundbell.muaythai.R
import com.roundbell.muaythai.RoundBellApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.Calendar

/** Optional daily training reminders using inexact alarms (no exact-alarm permission needed). */
object Reminders {
    const val CHANNEL = "training_reminders"

    fun createChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, context.getString(R.string.reminder_channel), NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun pending(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context, 1001, Intent(context, ReminderReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(context: Context, hour: Int, minute: Int) {
        val am = context.getSystemService(AlarmManager::class.java) ?: return
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pending(context))
    }

    fun cancel(context: Context) {
        context.getSystemService(AlarmManager::class.java)?.cancel(pending(context))
    }

    fun canPost(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val app = context.applicationContext as RoundBellApp
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val s = app.container.settings.settings.first()
                val p = app.container.settings.profile.first()
                val today = LocalDate.now().dayOfWeek.value
                if (s.notifications && today in p.trainingDays && Reminders.canPost(context)) {
                    val open = PendingIntent.getActivity(
                        context, 0, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        PendingIntent.FLAG_IMMUTABLE
                    )
                    val n = NotificationCompat.Builder(context, Reminders.CHANNEL)
                        .setSmallIcon(R.drawable.ic_glove)
                        .setContentTitle("Time to train")
                        .setContentText(if (p.name.isNotBlank()) "${p.name}, your rounds are waiting." else "Your rounds are waiting.")
                        .setContentIntent(open)
                        .setAutoCancel(true)
                        .build()
                    @Suppress("MissingPermission")
                    NotificationManagerCompat.from(context).notify(2001, n)
                }
            } finally {
                pending.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        val app = context.applicationContext as RoundBellApp
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val s = app.container.settings.settings.first()
                if (s.notifications) Reminders.schedule(context, s.reminderHour, s.reminderMinute)
            } finally { pending.finish() }
        }
    }
}
