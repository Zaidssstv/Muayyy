package com.roundbell.muaythai.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.widget.Toast
import com.roundbell.muaythai.data.model.Exercise
import com.roundbell.muaythai.data.model.Intensity
import com.roundbell.muaythai.data.model.Section
import com.roundbell.muaythai.data.model.SectionType
import com.roundbell.muaythai.data.model.WorkItem
import com.roundbell.muaythai.domain.WorkoutMath
import com.roundbell.muaythai.domain.formatClock
import com.roundbell.muaythai.ui.AppViewModel
import com.roundbell.muaythai.ui.BuilderViewModel
import com.roundbell.muaythai.ui.Nav
import com.roundbell.muaythai.ui.components.CategoryBadge
import com.roundbell.muaythai.ui.components.ChoiceChips
import com.roundbell.muaythai.ui.components.RbCard
import com.roundbell.muaythai.ui.components.SectionTitle
import com.roundbell.muaythai.ui.components.Stepper
import com.roundbell.muaythai.ui.components.TimeStepper

/** Target of the exercise picker: add to a section, or replace an item. */
private data class PickTarget(val sectionUid: String, val replaceItemUid: String?)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuilderScreen(vm: AppViewModel, bvm: BuilderViewModel, nav: Nav) {
    val workout by bvm.workout.collectAsStateWithLifecycle()
    val dirty by bvm.dirty.collectAsStateWithLifecycle()
    val profile by vm.profile.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var pickSection by rememberSaveable { mutableStateOf<String?>(null) }
    var pickReplace by rememberSaveable { mutableStateOf<String?>(null) }
    var editSection by rememberSaveable { mutableStateOf<String?>(null) }
    var editItem by rememberSaveable { mutableStateOf<String?>(null) }
    var renameSectionUid by rememberSaveable { mutableStateOf<String?>(null) }
    var showDetails by rememberSaveable { mutableStateOf(false) }
    var showBulk by rememberSaveable { mutableStateOf(false) }
    var confirmLeave by rememberSaveable { mutableStateOf(false) }
    var customFor by rememberSaveable { mutableStateOf(false) }

    BackHandler(enabled = dirty) { confirmLeave = true }

    val w = workout
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (w == null) "Workout builder" else w.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = {
                IconButton(onClick = { if (dirty) confirmLeave = true else nav.back() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                }
            },
            actions = {
                IconButton(onClick = { showDetails = true }) { Icon(Icons.Default.Edit, "Edit name, notes and intensity") }
                TextButton(onClick = {
                    bvm.save { Toast.makeText(context, "Workout saved", Toast.LENGTH_SHORT).show() }
                }, enabled = w != null) { Text("SAVE") }
            }
        )
    }) { pad ->
        if (w == null) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) { Text("Loading…") }
            return@Scaffold
        }
        val summary = WorkoutMath.summary(w, profile.weightForCalories)
        Column(Modifier.fillMaxSize().padding(pad)) {
            // Live summary bar
            Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    SummaryCell(formatClock(summary.totalSec), "Total")
                    SummaryCell(summary.exercises.toString(), "Exercises")
                    SummaryCell(summary.rounds.toString(), "Rounds")
                    SummaryCell(formatClock(summary.restSec), "Rest")
                    SummaryCell("~${summary.calories}", "kcal")
                }
            }
            LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                item {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Intensity: ${w.intensity.label}", style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                        TextButton(onClick = { showBulk = true }) { Text("Bulk timing") }
                    }
                    if (w.notes.isNotBlank()) Text(w.notes, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (w.sections.isEmpty()) item {
                    Text("This workout is empty. Add a block below, then add exercises.", Modifier.padding(vertical = 24.dp))
                }
                items(w.sections, key = { it.uid }) { s ->
                    SectionCard(
                        s = s,
                        onAdd = { pickSection = s.uid; pickReplace = null },
                        onEditSection = { editSection = s.uid },
                        onRename = { renameSectionUid = s.uid },
                        onMove = { d -> bvm.moveSection(s.uid, d) },
                        onDuplicate = { bvm.duplicateSection(s.uid) },
                        onDelete = { bvm.removeSection(s.uid) },
                        onItemEdit = { editSection = s.uid; editItem = it.uid },
                        onItemMove = { item, d -> bvm.moveItem(s.uid, item.uid, d) }
                    )
                }
                item {
                    SectionTitle("Add block")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionType.entries.forEach { t ->
                            OutlinedButton(onClick = { bvm.addSection(t) }, Modifier.weight(1f),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)) {
                                Text(t.label, maxLines = 1, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
            Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
                Button(
                    onClick = {
                        if (bvm.start()) nav.player()
                        else Toast.makeText(context, "Add at least one exercise first", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth().padding(12.dp).height(56.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text("START WORKOUT · ${formatClock(summary.totalSec)}", fontWeight = FontWeight.Bold)
                }
            }
        }

        // ---------- dialogs ----------
        val sectionForEdit = w.sections.firstOrNull { it.uid == editSection }
        val itemForEdit = sectionForEdit?.items?.firstOrNull { it.uid == editItem }
        if (sectionForEdit != null && itemForEdit != null) {
            ItemEditDialog(
                item = itemForEdit,
                onDismiss = { editItem = null; editSection = null },
                onSave = { sec, reps, rest, note -> bvm.updateItem(sectionForEdit.uid, itemForEdit.uid, sec, reps, rest, note); editItem = null; editSection = null },
                onReplace = { pickSection = sectionForEdit.uid; pickReplace = itemForEdit.uid; editItem = null; editSection = null },
                onDuplicate = { bvm.duplicateItem(sectionForEdit.uid, itemForEdit.uid); editItem = null; editSection = null },
                onDelete = { bvm.removeItem(sectionForEdit.uid, itemForEdit.uid); editItem = null; editSection = null }
            )
        } else if (sectionForEdit != null && editItem == null) {
            SectionEditDialog(sectionForEdit, bvm, onDismiss = { editSection = null })
        }

        w.sections.firstOrNull { it.uid == renameSectionUid }?.let { s ->
            TextInputDialog("Rename block", s.title, onDismiss = { renameSectionUid = null }) {
                bvm.renameSection(s.uid, it); renameSectionUid = null
            }
        }

        if (pickSection != null) {
            val target = PickTarget(pickSection!!, pickReplace)
            ExercisePickerDialog(
                vm = vm,
                title = if (target.replaceItemUid != null) "Replace with…" else "Add exercise",
                onDismiss = { pickSection = null; pickReplace = null },
                onCustom = { customFor = true },
                onPick = { e ->
                    if (target.replaceItemUid != null) bvm.replaceItem(target.sectionUid, target.replaceItemUid, e)
                    else bvm.addExercise(target.sectionUid, e)
                    pickSection = null; pickReplace = null
                }
            )
        }
        if (customFor) {
            CustomExerciseDialog(onDismiss = { customFor = false }) { name, cat, sec, desc ->
                val target = pickSection
                val replace = pickReplace
                vm.saveCustomExercise(name, cat, sec, desc) { e: Exercise ->
                    if (target != null) {
                        if (replace != null) bvm.replaceItem(target, replace, e) else bvm.addExercise(target, e)
                    }
                }
                customFor = false; pickSection = null; pickReplace = null
            }
        }

        if (showDetails) WorkoutDetailsDialog(w.name, w.notes, w.intensity, onDismiss = { showDetails = false }) { n, notes, i ->
            bvm.rename(n); bvm.setNotes(notes); bvm.setIntensity(i); showDetails = false
        }
        if (showBulk) BulkTimingDialog(settings.defaultWorkSec, settings.defaultRestSec, onDismiss = { showBulk = false }) { work, rest ->
            bvm.applyWorkToAll(work); bvm.applyRestToAll(rest); showBulk = false
        }
        if (confirmLeave) AlertDialog(
            onDismissRequest = { confirmLeave = false },
            title = { Text("Unsaved changes") },
            text = { Text("Save this workout before leaving?") },
            confirmButton = { TextButton(onClick = { confirmLeave = false; bvm.save { nav.back() } }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { confirmLeave = false; nav.back() }) { Text("Discard") } }
        )
    }
}

@Composable
private fun SummaryCell(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SectionCard(
    s: Section,
    onAdd: () -> Unit, onEditSection: () -> Unit, onRename: () -> Unit, onMove: (Int) -> Unit,
    onDuplicate: () -> Unit, onDelete: () -> Unit,
    onItemEdit: (WorkItem) -> Unit, onItemMove: (WorkItem, Int) -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    val blockSec = s.items.sumOf { it.seconds + it.restSec }
    RbCard(Modifier.padding(vertical = 6.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.title.uppercase(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary)
                    val setsTxt = if (s.sets > 1) " × ${s.sets} sets" else ""
                    val restTxt = if (s.restAfterSec > 0) " · rest after ${formatClock(s.restAfterSec)}" else ""
                    Text("${s.type.label} · ${formatClock(blockSec)}$setsTxt$restTxt", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onEditSection) { Icon(Icons.Default.Edit, "Edit ${s.title} timing") }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More options for ${s.title}") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; onRename() })
                        DropdownMenuItem(text = { Text("Move up") }, onClick = { menu = false; onMove(-1) })
                        DropdownMenuItem(text = { Text("Move down") }, onClick = { menu = false; onMove(1) })
                        DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; onDuplicate() })
                        DropdownMenuItem(text = { Text("Delete block") }, onClick = { menu = false; onDelete() })
                    }
                }
            }
            s.items.forEach { item ->
                HorizontalDivider(Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outlineVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CategoryBadge(item.category, size = 36)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f).padding(vertical = 4.dp)) {
                        Text(item.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val reps = item.reps?.let { " · $it reps" } ?: ""
                        val rest = if (item.restSec > 0) " · rest ${formatClock(item.restSec)}" else ""
                        Text("${formatClock(item.seconds)}$reps$rest", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (item.note.isNotBlank()) Text(item.note, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary, maxLines = 2)
                    }
                    IconButton(onClick = { onItemMove(item, -1) }) { Icon(Icons.Default.KeyboardArrowUp, "Move ${item.name} up") }
                    IconButton(onClick = { onItemMove(item, 1) }) { Icon(Icons.Default.KeyboardArrowDown, "Move ${item.name} down") }
                    IconButton(onClick = { onItemEdit(item) }) { Icon(Icons.Default.Edit, "Edit ${item.name}") }
                }
            }
            TextButton(onClick = onAdd) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Add exercise")
            }
        }
    }
}

@Composable
private fun SectionEditDialog(s: Section, bvm: BuilderViewModel, onDismiss: () -> Unit) {
    val total = s.items.sumOf { it.seconds }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(s.title) },
        text = {
            Column {
                if ((s.type == SectionType.WARMUP || s.type == SectionType.COOLDOWN) && s.items.isNotEmpty()) {
                    TimeStepper("${s.type.label} length", total, step = 30, min = s.items.size * 5) { bvm.setSectionTotal(s.uid, it) }
                    Text("Time is spread evenly across the exercises in this block.", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Stepper("Sets / rounds", s.sets.toString(), onMinus = { bvm.setSets(s.uid, s.sets - 1) }, onPlus = { bvm.setSets(s.uid, s.sets + 1) })
                TimeStepper("Rest after block", s.restAfterSec, step = 15, max = 600) { bvm.setSectionRest(s.uid, it) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
private fun ItemEditDialog(
    item: WorkItem, onDismiss: () -> Unit, onSave: (Int, Int?, Int, String) -> Unit,
    onReplace: () -> Unit, onDuplicate: () -> Unit, onDelete: () -> Unit
) {
    var sec by rememberSaveable(item.uid) { mutableStateOf(item.seconds) }
    var rest by rememberSaveable(item.uid) { mutableStateOf(item.restSec) }
    var reps by rememberSaveable(item.uid) { mutableStateOf(item.reps?.toString() ?: "") }
    var note by rememberSaveable(item.uid) { mutableStateOf(item.note) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(item.name) },
        text = {
            Column {
                TimeStepper("Duration", sec, step = 5, min = 5) { sec = it }
                TimeStepper("Rest after", rest, step = 5, max = 600) { rest = it }
                OutlinedTextField(reps, { v -> reps = v.filter { it.isDigit() }.take(3) }, label = { Text("Reps (optional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(note, { note = it.take(120) }, label = { Text("Note / cue") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = onReplace) { Text("Replace") }
                    TextButton(onClick = onDuplicate) { Text("Duplicate") }
                    TextButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, null, Modifier.size(18.dp)); Text("Remove", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(sec, reps.toIntOrNull(), rest, note.trim()) }) { Text("Apply") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun ExercisePickerDialog(vm: AppViewModel, title: String, onDismiss: () -> Unit, onCustom: () -> Unit, onPick: (Exercise) -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Close") }
                    Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    TextButton(onClick = onCustom) { Icon(Icons.Default.Add, null); Text("Custom") }
                }
                ExerciseBrowser(vm, Modifier.weight(1f), onPick)
            }
        }
    }
}

@Composable
private fun WorkoutDetailsDialog(name: String, notes: String, intensity: Intensity, onDismiss: () -> Unit, onSave: (String, String, Intensity) -> Unit) {
    var n by rememberSaveable { mutableStateOf(name) }
    var t by rememberSaveable { mutableStateOf(notes) }
    var i by rememberSaveable { mutableStateOf(intensity.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Workout details") },
        text = {
            Column {
                OutlinedTextField(n, { n = it.take(60) }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(t, { t = it.take(500) }, label = { Text("Notes") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("Intensity", style = MaterialTheme.typography.labelLarge)
                ChoiceChips(Intensity.entries.toList(), Intensity.valueOf(i), { it.label }) { i = it.name }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(n.trim(), t.trim(), Intensity.valueOf(i)) }) { Text("Apply") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun BulkTimingDialog(work0: Int, rest0: Int, onDismiss: () -> Unit, onApply: (Int, Int) -> Unit) {
    var work by rememberSaveable { mutableStateOf(work0) }
    var rest by rememberSaveable { mutableStateOf(rest0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bulk timing") },
        text = {
            Column {
                Text("Applies to every exercise in round and conditioning blocks.", style = MaterialTheme.typography.bodySmall)
                TimeStepper("Work", work, step = 5, min = 5) { work = it }
                TimeStepper("Rest between", rest, step = 5, max = 300) { rest = it }
            }
        },
        confirmButton = { TextButton(onClick = { onApply(work, rest) }) { Text("Apply to all") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun TextInputDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by rememberSaveable { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(text, { text = it.take(60) }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { onSave(text.trim()) }, enabled = text.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
