package com.roundbell.muaythai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roundbell.muaythai.data.model.Difficulty
import com.roundbell.muaythai.data.model.Equipment
import com.roundbell.muaythai.data.model.Goal
import com.roundbell.muaythai.data.model.Intensity
import com.roundbell.muaythai.data.model.TrainingStyle
import com.roundbell.muaythai.data.model.enumOr
import com.roundbell.muaythai.domain.GeneratorParams
import com.roundbell.muaythai.ui.AppViewModel
import com.roundbell.muaythai.ui.Nav
import com.roundbell.muaythai.ui.components.ChoiceChips
import com.roundbell.muaythai.ui.components.MultiChips
import com.roundbell.muaythai.ui.components.SectionTitle
import kotlin.math.roundToInt

private val presets = listOf(5, 10, 15, 20, 30, 45, 60)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeneratorScreen(vm: AppViewModel, nav: Nav) {
    val profile by vm.profile.collectAsStateWithLifecycle()
    val exercises by vm.exercises.collectAsStateWithLifecycle()
    // Saveable primitives so choices survive rotation.
    var goal by rememberSaveable { mutableStateOf<String?>(null) }
    var diff by rememberSaveable { mutableStateOf<String?>(null) }
    var minutes by rememberSaveable { mutableStateOf(-1) }
    var style by rememberSaveable { mutableStateOf(TrainingStyle.FULL.name) }
    var intensity by rememberSaveable { mutableStateOf(Intensity.MODERATE.name) }
    var equip by rememberSaveable { mutableStateOf(Equipment.NONE.name) }

    LaunchedEffect(profile) {
        if (goal == null) goal = profile.goal.name
        if (diff == null) diff = profile.level.name
        if (minutes < 0) minutes = profile.preferredMinutes
    }
    val eqSet = equip.split(",").mapNotNull { runCatching { Equipment.valueOf(it) }.getOrNull() }.toSet()
    val params = GeneratorParams(
        goal = enumOr(goal, profile.goal), difficulty = enumOr(diff, profile.level),
        minutes = if (minutes > 0) minutes else profile.preferredMinutes,
        style = enumOr(style, TrainingStyle.FULL), equipment = eqSet.ifEmpty { setOf(Equipment.NONE) },
        intensity = enumOr(intensity, Intensity.MODERATE)
    )

    Scaffold(topBar = {
        TopAppBar(title = { Text("Workout generator") },
            navigationIcon = { IconButton(onClick = { nav.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } })
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            SectionTitle("Goal")
            ChoiceChips(Goal.entries.toList(), params.goal, { it.label }) { goal = it.name }
            SectionTitle("Difficulty")
            ChoiceChips(Difficulty.entries.toList(), params.difficulty, { it.label }) { diff = it.name }
            SectionTitle("Duration · ${params.minutes} min")
            ChoiceChips(presets, params.minutes.takeIf { it in presets } ?: -1, { "$it min" }) { minutes = it }
            Slider(
                value = params.minutes.toFloat(), onValueChange = { minutes = it.roundToInt() },
                valueRange = 3f..120f, modifier = Modifier.fillMaxWidth()
            )
            SectionTitle("Training style")
            ChoiceChips(TrainingStyle.entries.toList(), params.style, { it.label }) { style = it.name }
            SectionTitle("Equipment available")
            MultiChips(Equipment.entries.toList(), params.equipment, { it.label }) { e ->
                val next = if (e == Equipment.NONE) setOf(Equipment.NONE)
                else (if (e in eqSet) eqSet - e else eqSet + e - Equipment.NONE).ifEmpty { setOf(Equipment.NONE) }
                equip = next.joinToString(",") { it.name }
            }
            SectionTitle("Intensity")
            ChoiceChips(Intensity.entries.toList(), params.intensity, { it.label }) { intensity = it.name }

            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    enabled = exercises.isNotEmpty(),
                    onClick = { vm.startWorkout(vm.generate(params)); nav.player() },
                    modifier = Modifier.weight(1f).height(56.dp)
                ) { Text("Generate & start") }
                Button(
                    enabled = exercises.isNotEmpty(),
                    onClick = { vm.setDraft(vm.generate(params)); nav.builder(-1) },
                    modifier = Modifier.weight(1f).height(56.dp)
                ) { Text("GENERATE") }
            }
            Text("\"Generate\" opens the workout in the builder so you can adjust anything before starting.",
                Modifier.padding(vertical = 12.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
