package com.roundbell.muaythai.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.roundbell.muaythai.data.model.Difficulty
import com.roundbell.muaythai.data.model.Goal
import com.roundbell.muaythai.data.model.ThemeMode
import com.roundbell.muaythai.data.model.Units
import com.roundbell.muaythai.data.model.enumOr
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val countdownSounds: Boolean = true,
    val transitionSounds: Boolean = true,
    val restSounds: Boolean = true,
    val haptics: Boolean = true,
    val voice: Boolean = true,
    val countdownSeconds: Int = 5,
    val units: Units = Units.METRIC,
    val notifications: Boolean = false,
    val reminderHour: Int = 18,
    val reminderMinute: Int = 0,
    val defaultWorkSec: Int = 30,
    val defaultRestSec: Int = 15,
    val defaultRoundRestSec: Int = 60,
    val keepScreenOn: Boolean = true
)

data class UserProfile(
    val name: String = "",
    val age: Int? = null,
    val heightCm: Float? = null,
    val weightKg: Float? = null,
    val level: Difficulty = Difficulty.BEGINNER,
    val goal: Goal = Goal.GENERAL,
    val preferredMinutes: Int = 20,
    /** 1 = Monday … 7 = Sunday */
    val trainingDays: Set<Int> = setOf(1, 3, 5)
) {
    val weightForCalories: Double get() = (weightKg ?: 70f).toDouble().coerceIn(30.0, 250.0)
}

class SettingsRepository(private val context: Context) {
    private object K {
        val theme = stringPreferencesKey("theme")
        val cdSounds = booleanPreferencesKey("cd_sounds")
        val trSounds = booleanPreferencesKey("tr_sounds")
        val restSounds = booleanPreferencesKey("rest_sounds")
        val haptics = booleanPreferencesKey("haptics")
        val voice = booleanPreferencesKey("voice")
        val cdSec = intPreferencesKey("cd_sec")
        val units = stringPreferencesKey("units")
        val notif = booleanPreferencesKey("notif")
        val remH = intPreferencesKey("rem_h")
        val remM = intPreferencesKey("rem_m")
        val work = intPreferencesKey("def_work")
        val rest = intPreferencesKey("def_rest")
        val roundRest = intPreferencesKey("def_round_rest")
        val keepOn = booleanPreferencesKey("keep_on")

        val pName = stringPreferencesKey("p_name")
        val pAge = intPreferencesKey("p_age")
        val pHeight = floatPreferencesKey("p_height")
        val pWeight = floatPreferencesKey("p_weight")
        val pLevel = stringPreferencesKey("p_level")
        val pGoal = stringPreferencesKey("p_goal")
        val pMinutes = intPreferencesKey("p_minutes")
        val pDays = stringPreferencesKey("p_days")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        val d = AppSettings()
        AppSettings(
            themeMode = enumOr(p[K.theme], d.themeMode),
            countdownSounds = p[K.cdSounds] ?: d.countdownSounds,
            transitionSounds = p[K.trSounds] ?: d.transitionSounds,
            restSounds = p[K.restSounds] ?: d.restSounds,
            haptics = p[K.haptics] ?: d.haptics,
            voice = p[K.voice] ?: d.voice,
            countdownSeconds = p[K.cdSec] ?: d.countdownSeconds,
            units = enumOr(p[K.units], d.units),
            notifications = p[K.notif] ?: d.notifications,
            reminderHour = p[K.remH] ?: d.reminderHour,
            reminderMinute = p[K.remM] ?: d.reminderMinute,
            defaultWorkSec = p[K.work] ?: d.defaultWorkSec,
            defaultRestSec = p[K.rest] ?: d.defaultRestSec,
            defaultRoundRestSec = p[K.roundRest] ?: d.defaultRoundRestSec,
            keepScreenOn = p[K.keepOn] ?: d.keepScreenOn
        )
    }

    val profile: Flow<UserProfile> = context.dataStore.data.map { p ->
        val d = UserProfile()
        UserProfile(
            name = p[K.pName] ?: d.name,
            age = p[K.pAge],
            heightCm = p[K.pHeight],
            weightKg = p[K.pWeight],
            level = enumOr(p[K.pLevel], d.level),
            goal = enumOr(p[K.pGoal], d.goal),
            preferredMinutes = p[K.pMinutes] ?: d.preferredMinutes,
            trainingDays = p[K.pDays]?.split(",")?.mapNotNull { it.toIntOrNull() }?.toSet() ?: d.trainingDays
        )
    }

    suspend fun currentSettings(): AppSettings = settings.first()
    suspend fun currentProfile(): UserProfile = profile.first()

    suspend fun updateSettings(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { p ->
            val cur = settingsFrom(p)
            val s = transform(cur)
            p[K.theme] = s.themeMode.name
            p[K.cdSounds] = s.countdownSounds
            p[K.trSounds] = s.transitionSounds
            p[K.restSounds] = s.restSounds
            p[K.haptics] = s.haptics
            p[K.voice] = s.voice
            p[K.cdSec] = s.countdownSeconds
            p[K.units] = s.units.name
            p[K.notif] = s.notifications
            p[K.remH] = s.reminderHour
            p[K.remM] = s.reminderMinute
            p[K.work] = s.defaultWorkSec
            p[K.rest] = s.defaultRestSec
            p[K.roundRest] = s.defaultRoundRestSec
            p[K.keepOn] = s.keepScreenOn
        }
    }

    private fun settingsFrom(p: Preferences): AppSettings {
        val d = AppSettings()
        return AppSettings(
            enumOr(p[K.theme], d.themeMode), p[K.cdSounds] ?: d.countdownSounds, p[K.trSounds] ?: d.transitionSounds,
            p[K.restSounds] ?: d.restSounds, p[K.haptics] ?: d.haptics, p[K.voice] ?: d.voice,
            p[K.cdSec] ?: d.countdownSeconds, enumOr(p[K.units], d.units), p[K.notif] ?: d.notifications,
            p[K.remH] ?: d.reminderHour, p[K.remM] ?: d.reminderMinute, p[K.work] ?: d.defaultWorkSec,
            p[K.rest] ?: d.defaultRestSec, p[K.roundRest] ?: d.defaultRoundRestSec, p[K.keepOn] ?: d.keepScreenOn
        )
    }

    suspend fun saveProfile(u: UserProfile) {
        context.dataStore.edit { p ->
            p[K.pName] = u.name
            if (u.age != null) p[K.pAge] = u.age else p.remove(K.pAge)
            if (u.heightCm != null) p[K.pHeight] = u.heightCm else p.remove(K.pHeight)
            if (u.weightKg != null) p[K.pWeight] = u.weightKg else p.remove(K.pWeight)
            p[K.pLevel] = u.level.name
            p[K.pGoal] = u.goal.name
            p[K.pMinutes] = u.preferredMinutes
            p[K.pDays] = u.trainingDays.sorted().joinToString(",")
        }
    }

    suspend fun clearAll() { context.dataStore.edit { it.clear() } }
}
