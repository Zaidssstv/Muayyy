package com.roundbell.muaythai.data.model

enum class Category(val label: String, val short: String) {
    FOOTWORK("Stance & Footwork", "Footwork"),
    BOXING("Boxing", "Boxing"),
    ELBOWS("Elbows", "Elbows"),
    KNEES("Knees", "Knees"),
    KICKS("Kicks", "Kicks"),
    DEFENSE("Defense", "Defense"),
    CLINCH("Clinch", "Clinch"),
    CONDITIONING("Conditioning", "Conditioning"),
    MOBILITY("Mobility & Warm-up", "Mobility"),
    CUSTOM("Custom", "Custom")
}

enum class Difficulty(val label: String) {
    BEGINNER("Beginner"), INTERMEDIATE("Intermediate"), ADVANCED("Advanced")
}

enum class Goal(val label: String) {
    TECHNIQUE("Technique"), CARDIO("Cardio"), CONDITIONING("Conditioning"), SPEED("Speed"),
    POWER("Power"), FAT_LOSS("Fat loss"), ENDURANCE("Endurance"), GENERAL("General Muay Thai"),
    SHADOWBOXING("Shadowboxing"), FIGHT_PREP("Fight preparation")
}

enum class TrainingStyle(val label: String) {
    BOXING("Boxing"), KICKS("Kicks"), KNEES("Knees"), ELBOWS("Elbows"), CLINCH("Clinch"),
    DEFENSE("Defense"), FOOTWORK("Footwork"), FULL("Full Muay Thai"),
    CONDITIONING("Conditioning"), MIXED("Mixed")
}

enum class Equipment(val label: String) {
    NONE("None"), HEAVY_BAG("Heavy bag"), JUMP_ROPE("Jump rope"), BANDS("Resistance bands"),
    DUMBBELLS("Dumbbells"), KETTLEBELL("Kettlebell"), GLOVES("Boxing gloves"), MITTS("Focus mitts")
}

enum class Intensity(val label: String, val met: Double) {
    EASY("Easy", 5.0), MODERATE("Moderate", 7.5), HARD("Hard", 10.0), MAXIMUM("Maximum", 12.0)
}

enum class SectionType(val label: String) {
    WARMUP("Warm-up"), ROUND("Round"), CONDITIONING("Conditioning"), COOLDOWN("Cooldown")
}

enum class ThemeMode(val label: String) { DARK("Dark"), LIGHT("Light"), SYSTEM("System") }

enum class Units(val label: String) { METRIC("Metric (kg, cm)"), IMPERIAL("Imperial (lb, in)") }

inline fun <reified T : Enum<T>> enumOr(name: String?, default: T): T =
    if (name == null) default else runCatching { enumValueOf<T>(name) }.getOrDefault(default)
