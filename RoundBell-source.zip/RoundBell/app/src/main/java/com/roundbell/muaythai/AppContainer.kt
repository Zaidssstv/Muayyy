package com.roundbell.muaythai

import android.content.Context
import com.roundbell.muaythai.data.TrainingRepository
import com.roundbell.muaythai.data.db.AppDatabase
import com.roundbell.muaythai.data.model.Workout
import com.roundbell.muaythai.data.prefs.SettingsRepository
import com.roundbell.muaythai.player.CueManager
import com.roundbell.muaythai.player.SessionStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Simple manual dependency container (no DI framework needed). */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    val db = AppDatabase.get(appContext)
    val repo = TrainingRepository(db)
    val settings = SettingsRepository(appContext)
    val session = SessionStore(appContext)
    val cues by lazy { CueManager(appContext) }
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Unsaved workout handed from the generator / exercise screen to the builder. */
    @Volatile var draft: Workout? = null
}
