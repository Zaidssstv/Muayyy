package com.roundbell.muaythai.ui.screens

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.compose.foundation.selection.toggleable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roundbell.muaythai.data.model.Difficulty
import com.roundbell.muaythai.data.model.Goal
import com.roundbell.muaythai.data.model.ThemeMode
import com.roundbell.muaythai.data.model.Units
import com.roundbell.muaythai.data.prefs.UserProfile
import com.roundbell.muaythai.ui.AppViewModel
import com.roundbell.muaythai.ui.components.ChoiceChips
import com.roundbell.muaythai.ui.components.MultiChips
import com.roundbell.muaythai.ui.components.RbCard
import com.roundbell.muaythai.ui.components.SectionTitle
import com.roundbell.muaythai.ui.components.Stepper
import com.roundbell.muaythai.ui.components.TimeStepper
import java.util.Locale

private const val KG_PER_LB = 0.45359237f
private const val CM_PER_IN = 2.54f
private val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(vm: AppViewModel) {
    val profile by vm.profile.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val imperial = s.units == Units.IMPERIAL

    // Editable profile text fields (saved explicitly).
    var name by rememberSaveable { mutableStateOf("") }
    var age by rememberSaveable { mutableStateOf("") }
    var height by rememberSaveable { mutableStateOf("") }
    var weight by rememberSaveable { mutableStateOf("") }
    var confirmReset by rememberSaveable { mutableStateOf(false) }

    fun fmt(v: Float) = if (v % 1f == 0f) v.toInt().toString() else String.format(Locale.US, "%.1f", v)
    fun fillFrom(p: UserProfile) {
        name = p.name
        age = p.age?.toString() ?: ""
        height = p.heightCm?.let { fmt(if (imperial) it / CM_PER_IN else it) } ?: ""
        weight = p.weightKg?.let { fmt(if (imperial) it / KG_PER_LB else it) } ?: ""
    }
    // Refill only when the stored text-backed values (or units) change, so chip edits never wipe typing.
    LaunchedEffect(profile.name, profile.age, profile.heightCm, profile.weightKg, imperial) { fillFrom(profile) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.updateSettings { it.copy(notifications = true) }
        else Toast.makeText(context, "Notifications permission denied — reminders stay off", Toast.LENGTH_LONG).show()
    }
    fun enableReminders(on: Boolean) {
        if (!on) { vm.updateSettings { it.copy(notifications = false) }; return }
        val needs = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needs) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else vm.updateSettings { it.copy(notifications = true) }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Profile & settings") }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            // ---------------- Profile ----------------
            SectionTitle("Profile")
            RbCard {
                Column(Modifier.padding(12.dp)) {
                    OutlinedTextField(name, { name = it.take(30) }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row {
                        NumField(age, { age = it }, "Age", Modifier.weight(1f), decimals = false)
                        Spacer(Modifier.width(8.dp))
                        NumField(height, { height = it }, if (imperial) "Height (in)" else "Height (cm)", Modifier.weight(1f))
                        Spacer(Modifier.width(8.dp))
                        NumField(weight, { weight = it }, if (imperial) "Weight (lb)" else "Weight (kg)", Modifier.weight(1f))
                    }
                    Text("Weight is used only to estimate calories. Everything stays on this device.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp))
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        val h = height.toFloatOrNull()?.let { if (imperial) it * CM_PER_IN else it }?.takeIf { it in 80f..250f }
                        val wkg = weight.toFloatOrNull()?.let { if (imperial) it * KG_PER_LB else it }?.takeIf { it in 25f..300f }
                        vm.saveProfile(profile.copy(name = name.trim(), age = age.toIntOrNull()?.takeIf { it in 5..110 }, heightCm = h, weightKg = wkg))
                        Toast.makeText(context, "Profile saved", Toast.LENGTH_SHORT).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Save profile") }
                }
            }
            SectionTitle("Training level")
            ChoiceChips(Difficulty.entries.toList(), profile.level, { it.label }) { vm.saveProfile(profile.copy(level = it)) }
            SectionTitle("Primary goal")
            ChoiceChips(Goal.entries.toList(), profile.goal, { it.label }) { vm.saveProfile(profile.copy(goal = it)) }
            SectionTitle("Preferred workout length")
            Stepper("Minutes", "${profile.preferredMinutes}",
                onMinus = { vm.saveProfile(profile.copy(preferredMinutes = (profile.preferredMinutes - 5).coerceAtLeast(5))) },
                onPlus = { vm.saveProfile(profile.copy(preferredMinutes = (profile.preferredMinutes + 5).coerceAtMost(120))) })
            SectionTitle("Training days")
            MultiChips((1..7).toList(), profile.trainingDays, { dayNames[it - 1] }) { d ->
                val next = if (d in profile.trainingDays) profile.trainingDays - d else profile.trainingDays + d
                vm.saveProfile(profile.copy(trainingDays = next))
            }

            // ---------------- Settings ----------------
            SectionTitle("Appearance")
            ChoiceChips(ThemeMode.entries.toList(), s.themeMode, { it.label }) { m -> vm.updateSettings { it.copy(themeMode = m) } }
            SectionTitle("Units")
            ChoiceChips(Units.entries.toList(), s.units, { it.label }) { u -> vm.updateSettings { it.copy(units = u) } }

            SectionTitle("Sound, voice & haptics")
            SwitchRow("Countdown beeps", s.countdownSounds) { v -> vm.updateSettings { it.copy(countdownSounds = v) } }
            SwitchRow("Exercise transition sounds", s.transitionSounds) { v -> vm.updateSettings { it.copy(transitionSounds = v) } }
            SwitchRow("Rest sounds", s.restSounds) { v -> vm.updateSettings { it.copy(restSounds = v) } }
            SwitchRow("Voice coaching (text-to-speech)", s.voice) { v -> vm.updateSettings { it.copy(voice = v) } }
            SwitchRow("Haptic feedback", s.haptics) { v -> vm.updateSettings { it.copy(haptics = v) } }
            SwitchRow("Keep screen on during workouts", s.keepScreenOn) { v -> vm.updateSettings { it.copy(keepScreenOn = v) } }
            Text("Get-ready countdown", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(top = 8.dp))
            ChoiceChips(listOf(3, 5, 10), s.countdownSeconds, { "$it s" }) { v -> vm.updateSettings { it.copy(countdownSeconds = v) } }

            SectionTitle("Workout defaults")
            TimeStepper("Exercise work time", s.defaultWorkSec, step = 5, min = 10, max = 600) { v -> vm.updateSettings { it.copy(defaultWorkSec = v) } }
            TimeStepper("Rest between exercises", s.defaultRestSec, step = 5, max = 300) { v -> vm.updateSettings { it.copy(defaultRestSec = v) } }
            TimeStepper("Rest between rounds", s.defaultRoundRestSec, step = 15, max = 600) { v -> vm.updateSettings { it.copy(defaultRoundRestSec = v) } }

            SectionTitle("Reminders")
            SwitchRow("Daily training reminder", s.notifications) { enableReminders(it) }
            if (s.notifications) {
                OutlinedButton(onClick = {
                    TimePickerDialog(context, { _, h, m -> vm.updateSettings { it.copy(reminderHour = h, reminderMinute = m) } },
                        s.reminderHour, s.reminderMinute, android.text.format.DateFormat.is24HourFormat(context)).show()
                }, modifier = Modifier.fillMaxWidth()) {
                    Text("Reminder time: %02d:%02d".format(s.reminderHour, s.reminderMinute))
                }
            }

            SectionTitle("Data")
            OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Reset all app data", color = MaterialTheme.colorScheme.error)
            }

            SectionTitle("About")
            val version = runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "1.0.0"
            Text("RoundBell — Muay Thai Trainer, version $version", style = MaterialTheme.typography.bodyMedium)
            Text("Works fully offline. No account, no ads, no tracking. Calorie values are estimates based on MET values and your weight. " +
                "Train safely: warm up properly and consult a professional if you have injuries.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(32.dp))
        }
    }

    if (confirmReset) AlertDialog(
        onDismissRequest = { confirmReset = false },
        title = { Text("Reset everything?") },
        text = { Text("This deletes your saved workouts, history, favourites, custom exercises, profile and settings. This cannot be undone.") },
        confirmButton = {
            TextButton(onClick = {
                confirmReset = false
                vm.resetAll { Toast.makeText(context, "App data reset", Toast.LENGTH_SHORT).show() }
            }) { Text("Reset", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
    )
}

@Composable
private fun NumField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier, decimals: Boolean = true) {
    OutlinedTextField(
        value = value,
        onValueChange = { v -> onChange(v.filter { it.isDigit() || (decimals && it == '.') }.take(6)) },
        label = { Text(label, maxLines = 1) }, singleLine = true, modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = if (decimals) KeyboardType.Decimal else KeyboardType.Number)
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(56.dp).toggleable(value = checked, role = Role.Switch, onValueChange = onChange),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = null)
    }
}
