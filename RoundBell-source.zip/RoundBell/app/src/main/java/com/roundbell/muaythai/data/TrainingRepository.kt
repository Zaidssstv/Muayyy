package com.roundbell.muaythai.data

import com.roundbell.muaythai.data.db.AppDatabase
import com.roundbell.muaythai.data.model.Exercise
import com.roundbell.muaythai.data.model.HistoryEntry
import com.roundbell.muaythai.data.model.Workout
import com.roundbell.muaythai.data.model.WorkoutCodec
import com.roundbell.muaythai.data.model.WorkoutEntity
import com.roundbell.muaythai.data.seed.ExerciseSeed
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class TrainingRepository(private val db: AppDatabase) {
    private val exDao = db.exerciseDao()
    private val wDao = db.workoutDao()
    private val hDao = db.historyDao()

    val exercises: Flow<List<Exercise>> = exDao.observeAll()
    val workouts: Flow<List<Workout>> = wDao.observeAll().map { list -> list.map { it.toDomain() } }
    val history: Flow<List<HistoryEntry>> = hDao.observeAll()

    suspend fun seed() = exDao.insertAllIgnore(ExerciseSeed.all)

    fun observeExercise(id: String): Flow<Exercise?> = exDao.observe(id)
    suspend fun exercise(id: String) = exDao.get(id)
    suspend fun allExercises() = exDao.all()
    suspend fun setExerciseFavorite(id: String, fav: Boolean) = exDao.setFavorite(id, fav)
    suspend fun saveCustomExercise(e: Exercise) = exDao.upsert(e.copy(isCustom = true))
    suspend fun deleteCustomExercise(id: String) = exDao.deleteCustom(id)

    suspend fun workout(id: Long): Workout? = wDao.get(id)?.toDomain()

    /** Inserts when id == 0, otherwise updates. Returns the id. */
    suspend fun saveWorkout(w: Workout): Long {
        val now = System.currentTimeMillis()
        return if (w.id == 0L) {
            wDao.insert(WorkoutEntity(0, w.name, w.notes, WorkoutCodec.encode(w), w.isFavorite, now, now, null))
        } else {
            val old = wDao.get(w.id)
            wDao.update(
                WorkoutEntity(w.id, w.name, w.notes, WorkoutCodec.encode(w), w.isFavorite,
                    old?.createdAt ?: now, now, old?.lastUsedAt)
            )
            w.id
        }
    }

    suspend fun setWorkoutFavorite(id: Long, fav: Boolean) = wDao.setFavorite(id, fav)
    suspend fun markWorkoutUsed(id: Long) = wDao.markUsed(id, System.currentTimeMillis())
    suspend fun deleteWorkout(id: Long) = wDao.delete(id)

    suspend fun addHistory(h: HistoryEntry): Long = hDao.insert(h)
    suspend fun historyEntry(id: Long) = hDao.get(id)
    suspend fun deleteHistory(id: Long) = hDao.delete(id)

    suspend fun resetAll() {
        hDao.clear(); wDao.clear(); exDao.clear(); seed()
    }
}

fun WorkoutEntity.toDomain(): Workout {
    val base = runCatching { WorkoutCodec.decode(json) }.getOrElse { Workout() }
    return base.copy(id = id, name = name, notes = notes, isFavorite = isFavorite,
        createdAt = createdAt, updatedAt = updatedAt, lastUsedAt = lastUsedAt)
}
