package com.roundbell.muaythai.player

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Beeps (ToneGenerator), haptics and on-device text-to-speech. No network, no audio assets. */
class CueManager(context: Context) : TextToSpeech.OnInitListener {
    private val app = context.applicationContext
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val tone: ToneGenerator? = runCatching { ToneGenerator(AudioManager.STREAM_MUSIC, 90) }.getOrNull()
    private val vibrator: Vibrator? = runCatching {
        if (Build.VERSION.SDK_INT >= 31) app.getSystemService(VibratorManager::class.java)?.defaultVibrator
        else @Suppress("DEPRECATION") app.getSystemService(Vibrator::class.java)
    }.getOrNull()

    fun prepareVoice() {
        if (tts == null) tts = runCatching { TextToSpeech(app, this) }.getOrNull()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val r = tts?.setLanguage(Locale.getDefault())
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts?.setLanguage(Locale.US)
            tts?.setSpeechRate(1.05f)
        }
    }

    fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rb-${System.nanoTime()}")
    }

    fun countdownBeep() { runCatching { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 120) } }
    fun workBeep() { runCatching { tone?.startTone(ToneGenerator.TONE_PROP_BEEP2, 450) } }
    fun restBeep() { runCatching { tone?.startTone(ToneGenerator.TONE_PROP_ACK, 350) } }
    fun finishBeep() { runCatching { tone?.startTone(ToneGenerator.TONE_PROP_PROMPT, 800) } }

    fun vibrate(ms: Long) {
        runCatching { vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE)) }
    }
}
