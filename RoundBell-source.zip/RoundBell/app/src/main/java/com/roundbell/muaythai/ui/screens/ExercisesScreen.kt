package com.roundbell.muaythai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roundbell.muaythai.data.model.Category
import com.roundbell.muaythai.data.model.Exercise
import com.roundbell.muaythai.ui.AppViewModel
import com.roundbell.muaythai.ui.Nav
import com.roundbell.muaythai.ui.components.CategoryBadge
import com.roundbell.muaythai.ui.components.ChoiceChips
import com.roundbell.muaythai.ui.components.DifficultyMeter
import com.roundbell.muaythai.ui.components.EmptyState
import com.roundbell.muaythai.ui.components.RbCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExercisesScreen(vm: AppViewModel, nav: Nav) {
    var creating by remember { mutableStateOf(false) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("Exercises") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { creating = true }, icon = { Icon(Icons.Default.Add, null) }, text = { Text("Custom") })
        }
    ) { pad ->
        ExerciseBrowser(vm, Modifier.padding(pad)) { nav.exercise(it.id) }
    }
    if (creating) CustomExerciseDialog(onDismiss = { creating = false }) { name, cat, sec, desc ->
        vm.saveCustomExercise(name, cat, sec, desc); creating = false
    }
}

/** Searchable, filterable exercise list reused by the library and the builder's picker. */
@Composable
fun ExerciseBrowser(vm: AppViewModel, modifier: Modifier = Modifier, onPick: (Exercise) -> Unit) {
    val all by vm.exercises.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var cat by rememberSaveable { mutableStateOf<String?>(null) }
    var favOnly by rememberSaveable { mutableStateOf(false) }
    val list = all.filter { e ->
        (cat == null || e.category.name == cat) && (!favOnly || e.isFavorite) &&
            (query.isBlank() || e.name.contains(query.trim(), true) || e.category.label.contains(query.trim(), true))
    }
    Column(modifier.fillMaxSize()) {
        OutlinedTextField(
            query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Search ${all.size} exercises") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilterChip(favOnly, { favOnly = !favOnly }, label = { Text("Favorites") },
                    leadingIcon = { Icon(Icons.Default.Favorite, null) })
            }
            item { FilterChip(cat == null, { cat = null }, label = { Text("All") }) }
            items(Category.entries.filter { c -> all.any { it.category == c } }) { c ->
                FilterChip(cat == c.name, { cat = if (cat == c.name) null else c.name }, label = { Text(c.short) })
            }
        }
        if (list.isEmpty()) EmptyState("No exercises found", if (favOnly) "Tap the heart on any exercise to add it here." else "Try a different search or category.")
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { e ->
                RbCard(onClick = { onPick(e) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        CategoryBadge(e.category)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(e.name, style = MaterialTheme.typography.titleMedium)
                            Text(e.category.label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            DifficultyMeter(e.difficulty)
                            if (e.isFavorite) Icon(Icons.Default.Favorite, "Favorite", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CustomExerciseDialog(onDismiss: () -> Unit, onSave: (String, Category, Int, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var secText by remember { mutableStateOf("30") }
    var cat by remember { mutableStateOf(Category.CUSTOM) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom exercise") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(secText, { secText = it.filter(Char::isDigit).take(4) }, label = { Text("Default duration (sec)") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(desc, { desc = it }, label = { Text("Description / cues") })
                Text("Category", style = MaterialTheme.typography.labelLarge)
                ChoiceChips(Category.entries.toList(), cat, { it.short }) { cat = it }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onSave(name, cat, secText.toIntOrNull() ?: 30, desc) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
