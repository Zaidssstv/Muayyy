package com.roundbell.muaythai.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roundbell.muaythai.R
import com.roundbell.muaythai.data.model.Workout
import com.roundbell.muaythai.data.model.WorkoutCodec
import com.roundbell.muaythai.domain.WorkoutMath
import com.roundbell.muaythai.domain.formatClock
import com.roundbell.muaythai.domain.formatMinutes
import com.roundbell.muaythai.ui.AppViewModel
import com.roundbell.muaythai.ui.Nav
import com.roundbell.muaythai.ui.components.EmptyState
import com.roundbell.muaythai.ui.components.RbCard
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutsScreen(vm: AppViewModel, nav: Nav) {
    val workouts by vm.workouts.collectAsStateWithLifecycle()
    val profile by vm.profile.collectAsStateWithLifecycle()
    var renaming by remember { mutableStateOf<Workout?>(null) }
    var deleting by remember { mutableStateOf<Workout?>(null) }
    var importing by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Workouts") }, actions = {
                TextButton(onClick = { importing = true }) { Text("Import") }
                IconButton(onClick = { nav.generator() }) { Icon(painterResource(R.drawable.ic_bolt), "Generate workout") }
                IconButton(onClick = { nav.builder(0) }) { Icon(Icons.Default.Add, "Create workout") }
            })
        },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        if (workouts.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                EmptyState("No saved workouts yet", "Generate one in seconds or build your own round by round.") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { nav.generator() }) { Text("Generate") }
                        Button(onClick = { nav.builder(0) }) { Text("Build") }
                    }
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(workouts, key = { it.id }) { w ->
                    val sum = WorkoutMath.summary(w, profile.weightForCalories)
                    var menu by remember { mutableStateOf(false) }
                    RbCard(onClick = { nav.builder(w.id) }) {
                        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(w.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("${formatClock(sum.totalSec)} · ${sum.exercises} exercises · ${sum.rounds} rounds",
                                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${w.intensity.label} · ~${sum.calories} kcal", style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { vm.toggleWorkoutFavorite(w) }) {
                                Icon(if (w.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    if (w.isFavorite) "Remove from favorites" else "Add to favorites",
                                    tint = if (w.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            FilledIconButton(onClick = { vm.startWorkout(w); nav.player() }, modifier = Modifier.height(48.dp)) {
                                Icon(Icons.Default.PlayArrow, "Start ${w.name}")
                            }
                            Box {
                                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More options") }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; nav.builder(w.id) })
                                    DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; renaming = w })
                                    DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; vm.duplicateWorkout(w) })
                                    DropdownMenuItem(text = { Text("Share") }, onClick = {
                                        menu = false
                                        val text = buildShareText(w, formatMinutes(sum.totalSec))
                                        context.startActivity(Intent.createChooser(
                                            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share workout"))
                                    })
                                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; deleting = w })
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    renaming?.let { w ->
        var name by remember(w.id) { mutableStateOf(w.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename workout") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name") }) },
            confirmButton = { TextButton(onClick = { vm.renameWorkout(w, name); renaming = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } }
        )
    }
    deleting?.let { w ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete workout?") },
            text = { Text("\"${w.name}\" will be removed. Your training history is kept.") },
            confirmButton = { TextButton(onClick = { vm.deleteWorkout(w); deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
    if (importing) {
        var json by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { importing = false },
            title = { Text("Import workout") },
            text = {
                Column {
                    Text("Paste a shared RoundBell workout (the code block starting with {).", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(json, { json = it }, Modifier.fillMaxWidth().height(160.dp), label = { Text("Workout code") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val start = json.indexOf('{'); val end = json.lastIndexOf('}')
                    val payload = if (start >= 0 && end > start) json.substring(start, end + 1) else json
                    vm.importWorkout(payload) { ok -> scope.launch { snack.showSnackbar(if (ok) "Workout imported" else "Couldn't read that workout code") } }
                    importing = false
                }) { Text("Import") }
            },
            dismissButton = { TextButton(onClick = { importing = false }) { Text("Cancel") } }
        )
    }
}

private fun buildShareText(w: Workout, duration: String): String = buildString {
    appendLine("🥊 ${w.name} ($duration)")
    w.sections.forEach { s ->
        if (s.items.isEmpty()) return@forEach
        appendLine()
        appendLine(if (s.sets > 1) "${s.title} ×${s.sets}" else s.title)
        s.items.forEach { i -> appendLine("• ${i.name} — ${i.reps?.let { "$it reps" } ?: formatClock(i.seconds)}") }
    }
    appendLine()
    appendLine("Import into RoundBell with this code:")
    append(WorkoutCodec.encode(w))
}
