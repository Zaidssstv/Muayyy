package com.roundbell.muaythai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roundbell.muaythai.ui.AppViewModel
import com.roundbell.muaythai.ui.Nav
import com.roundbell.muaythai.ui.components.CategoryBadge
import com.roundbell.muaythai.ui.components.DifficultyMeter
import com.roundbell.muaythai.ui.components.RbCard
import com.roundbell.muaythai.ui.components.SectionTitle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExerciseDetailScreen(vm: AppViewModel, nav: Nav, id: String) {
    val all by vm.exercises.collectAsStateWithLifecycle()
    val workouts by vm.workouts.collectAsStateWithLifecycle()
    val e = all.firstOrNull { it.id == id }
    var picking by remember { mutableStateOf(false) }
    var added by remember { mutableStateOf<String?>(null) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(e?.name ?: "") },
            navigationIcon = { IconButton(onClick = { nav.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = {
                if (e != null) {
                    if (e.isCustom) IconButton(onClick = { vm.deleteCustomExercise(e.id); nav.back() }) { Icon(Icons.Default.Delete, "Delete custom exercise") }
                    IconButton(onClick = { vm.toggleExerciseFavorite(e) }) {
                        Icon(if (e.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            if (e.isFavorite) "Remove from favorites" else "Add to favorites",
                            tint = if (e.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        )
    }) { pad ->
        if (e == null) { Text("Exercise not found", Modifier.padding(pad).padding(16.dp)); return@Scaffold }
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            RbCard {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    CategoryBadge(e.category, size = 72)
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(e.category.label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.height(4.dp))
                        DifficultyMeter(e.difficulty)
                        Spacer(Modifier.height(4.dp))
                        Text("Recommended: ${e.recommended}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(e.description, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { picking = true }, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("ADD TO WORKOUT")
            }
            added?.let { Text("Added to $it", Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.tertiary) }

            if (e.steps.isNotEmpty()) {
                SectionTitle("How to do it")
                e.steps.forEachIndexed { i, s ->
                    Row(Modifier.padding(vertical = 6.dp)) {
                        Text("${i + 1}", Modifier.width(28.dp), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        Text(s, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
            if (e.muscles.isNotEmpty()) { SectionTitle("Muscles & attributes"); Text(e.muscles.joinToString(" · ")) }
            SectionTitle("Equipment")
            Text(if (e.equipment.isEmpty()) "None — bodyweight" else e.equipment.joinToString { it.label })
            SectionTitle("Training purpose"); Text(e.purpose)
            if (e.variations.isNotEmpty()) {
                SectionTitle("Variations")
                e.variations.forEach { Text("• $it", Modifier.padding(vertical = 2.dp)) }
            }
            e.safety?.let {
                SectionTitle("Safety")
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Warning, "Safety note", tint = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.width(8.dp)); Text(it)
                }
            }
            Spacer(Modifier.height(12.dp))
            HorizontalDivider()
            Text("Video demonstrations can be added in a future update.", Modifier.padding(vertical = 12.dp),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
        }
    }

    if (picking && e != null) {
        AlertDialog(
            onDismissRequest = { picking = false },
            title = { Text("Add ${e.name} to…") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { picking = false; vm.setDraft(vm.newWorkoutWith(e)); nav.builder(-1) }) { Text("+ New workout") }
                    workouts.forEach { w ->
                        TextButton(onClick = { picking = false; vm.addExerciseToWorkout(w, e) { added = w.name } }) { Text(w.name) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { picking = false }) { Text("Cancel") } }
        )
    }
}
