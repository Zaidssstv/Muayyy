package com.roundbell.muaythai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.roundbell.muaythai.AppContainer
import com.roundbell.muaythai.data.model.Category
import com.roundbell.muaythai.data.model.Difficulty
import com.roundbell.muaythai.data.model.Equipment
import com.roundbell.muaythai.data.model.Exercise
import com.roundbell.muaythai.data.model.HistoryEntry
import com.roundbell.muaythai.data.model.Intensity
import com.roundbell.muaythai.data.model.Section
import com.roundbell.muaythai.data.model.SectionType
import com.roundbell.muaythai.data.model.TrainingStyle
import com.roundbell.muaythai.data.model.Workout
import com.roundbell.muaythai.data.model.WorkoutCodec
import com.roundbell.muaythai.data.model.newUid
import com.roundbell.muaythai.data.model.toWorkItem
import com.roundbell.muaythai.data.prefs.AppSettings
import com.roundbell.muaythai.data.prefs.UserProfile
import com.roundbell.muaythai.domain.GeneratorParams
import com.roundbell.muaythai.domain.WorkoutGenerator
import com.roundbell.muaythai.notify.Reminders
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

/** Activity-scoped ViewModel shared by the main screens. */
class AppViewModel(val c: AppContainer) : ViewModel() {
    private fun <T> kotlinx.coroutines.flow.Flow<T>.state(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), initial)

    val exercises: StateFlow<List<Exercise>> = c.repo.exercises.state(emptyList())
    val workouts: StateFlow<List<Workout>> = c.repo.workouts.state(emptyList())
    val history: StateFlow<List<HistoryEntry>> = c.repo.history.state(emptyList())
    val settings: StateFlow<AppSettings> = c.settings.settings.state(AppSettings())
    val profile: StateFlow<UserProfile> = c.settings.profile.state(UserProfile())
    val activeSession: StateFlow<String?> = c.session.activeName

    /** Today's suggestion: deterministic per day, built from the user's profile. */
    val suggested: StateFlow<Workout?> = combine(c.settings.profile, c.repo.exercises) { p, ex ->
        if (ex.isEmpty()) null
        else WorkoutGenerator.generate(defaultParams(p), ex, seed = LocalDate.now().toEpochDay())
            .copy(name = "Today's ${p.goal.label} session")
    }.state(null)

    fun defaultParams(p: UserProfile) = GeneratorParams(
        goal = p.goal, difficulty = p.level, minutes = p.preferredMinutes,
        style = TrainingStyle.FULL, equipment = setOf(Equipment.NONE),
        intensity = if (p.level == Difficulty.BEGINNER) Intensity.MODERATE else Intensity.HARD
    )

    fun quickWorkout(): Workout? {
        val ex = exercises.value
        if (ex.isEmpty()) return null
        val p = profile.value
        return WorkoutGenerator.generate(defaultParams(p).copy(minutes = 10, style = TrainingStyle.MIXED), ex)
            .copy(name = "Quick 10-minute session")
    }

    fun generate(params: GeneratorParams): Workout = WorkoutGenerator.generate(params, exercises.value)

    fun startWorkout(w: Workout) { c.session.start(w) }

    fun setDraft(w: Workout) { c.draft = w }

    fun toggleExerciseFavorite(e: Exercise) = viewModelScope.launch { c.repo.setExerciseFavorite(e.id, !e.isFavorite) }
    fun toggleWorkoutFavorite(w: Workout) = viewModelScope.launch { c.repo.setWorkoutFavorite(w.id, !w.isFavorite) }
    fun deleteWorkout(w: Workout) = viewModelScope.launch { c.repo.deleteWorkout(w.id) }
    fun renameWorkout(w: Workout, name: String) = viewModelScope.launch { c.repo.saveWorkout(w.copy(name = name.ifBlank { w.name })) }
    fun duplicateWorkout(w: Workout) = viewModelScope.launch {
        c.repo.saveWorkout(w.copy(id = 0, name = "${w.name} (copy)", isFavorite = false,
            sections = w.sections.map { s -> s.copy(uid = newUid(), items = s.items.map { it.copy(uid = newUid()) }) }))
    }
    fun deleteHistory(id: Long) = viewModelScope.launch { c.repo.deleteHistory(id) }

    fun saveCustomExercise(name: String, category: Category, seconds: Int, description: String, onSaved: (Exercise) -> Unit = {}) =
        viewModelScope.launch {
            val e = Exercise(
                id = "custom_" + newUid(), name = name.trim().ifBlank { "Custom exercise" }, category = category,
                difficulty = Difficulty.BEGINNER, description = description.ifBlank { "Your custom exercise." },
                steps = emptyList(), muscles = emptyList(), equipment = emptyList(), purpose = "Custom",
                recommended = "$seconds sec", defaultSeconds = seconds.coerceIn(5, 3600), defaultReps = null,
                variations = emptyList(), safety = null, isCustom = true
            )
            c.repo.saveCustomExercise(e); onSaved(e)
        }
    fun deleteCustomExercise(id: String) = viewModelScope.launch { c.repo.deleteCustomExercise(id) }

    /** Appends the exercise to the last round of an existing workout. */
    fun addExerciseToWorkout(workout: Workout, e: Exercise, onDone: () -> Unit) = viewModelScope.launch {
        val s = settings.value
        val item = e.toWorkItem(seconds = e.defaultSeconds, restSec = s.defaultRestSec)
        val sections = workout.sections.toMutableList()
        val idx = sections.indexOfLast { it.type == SectionType.ROUND }
        if (idx >= 0) sections[idx] = sections[idx].copy(items = sections[idx].items + item)
        else {
            val insertAt = sections.indexOfFirst { it.type == SectionType.COOLDOWN }.let { if (it < 0) sections.size else it }
            sections.add(insertAt, Section(type = SectionType.ROUND, title = "Round 1", items = listOf(item)))
        }
        c.repo.saveWorkout(workout.copy(sections = sections))
        onDone()
    }

    fun newWorkoutWith(e: Exercise): Workout {
        val s = settings.value
        return Workout(
            name = "${e.name} workout",
            sections = listOf(Section(type = SectionType.ROUND, title = "Round 1",
                items = listOf(e.toWorkItem(restSec = s.defaultRestSec))))
        )
    }

    fun importWorkout(json: String, onResult: (Boolean) -> Unit) = viewModelScope.launch {
        val w = runCatching { WorkoutCodec.decode(json) }.getOrNull()
        if (w == null || w.sections.isEmpty()) onResult(false)
        else { c.repo.saveWorkout(w.copy(id = 0)); onResult(true) }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) = viewModelScope.launch {
        c.settings.updateSettings(transform)
        val s = c.settings.currentSettings()
        if (s.notifications) Reminders.schedule(c.appContext, s.reminderHour, s.reminderMinute) else Reminders.cancel(c.appContext)
    }

    fun saveProfile(p: UserProfile) = viewModelScope.launch { c.settings.saveProfile(p) }

    fun resetAll(onDone: () -> Unit) = viewModelScope.launch {
        c.session.clear()
        Reminders.cancel(c.appContext)
        c.repo.resetAll()
        c.settings.clearAll()
        onDone()
    }
}
