package com.roundbell.muaythai.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.roundbell.muaythai.AppContainer
import com.roundbell.muaythai.data.model.Exercise
import com.roundbell.muaythai.data.model.Intensity
import com.roundbell.muaythai.data.model.Section
import com.roundbell.muaythai.data.model.SectionType
import com.roundbell.muaythai.data.model.WorkItem
import com.roundbell.muaythai.data.model.Workout
import com.roundbell.muaythai.data.model.newUid
import com.roundbell.muaythai.data.model.toWorkItem
import com.roundbell.muaythai.data.prefs.AppSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Editable workout draft.
 * workoutId: -1 = draft handed over via AppContainer.draft, 0 = new empty workout, >0 = saved workout.
 */
class BuilderViewModel(private val c: AppContainer, workoutId: Long) : ViewModel() {
    private val _w = MutableStateFlow<Workout?>(null)
    val workout: StateFlow<Workout?> = _w
    private val _dirty = MutableStateFlow(false)
    val dirty: StateFlow<Boolean> = _dirty
    private var defaults = AppSettings()

    init {
        viewModelScope.launch {
            defaults = c.settings.settings.first()
            _w.value = when {
                workoutId > 0 -> c.repo.workout(workoutId) ?: empty()
                workoutId < 0 -> (c.draft ?: empty()).also { _dirty.value = true }
                else -> empty().also { _dirty.value = true }
            }
        }
    }

    private fun empty(): Workout {
        return Workout(
            name = "Custom workout",
            sections = listOf(
                Section(type = SectionType.WARMUP, title = "Warm-up"),
                Section(type = SectionType.ROUND, title = "Round 1", restAfterSec = defaults.defaultRoundRestSec),
                Section(type = SectionType.COOLDOWN, title = "Cooldown")
            )
        )
    }

    private fun edit(f: (Workout) -> Workout) {
        val cur = _w.value ?: return
        _w.value = f(cur); _dirty.value = true
    }

    private fun editSection(uid: String, f: (Section) -> Section) =
        edit { w -> w.copy(sections = w.sections.map { if (it.uid == uid) f(it) else it }) }

    private fun editItem(sectionUid: String, itemUid: String, f: (WorkItem) -> WorkItem) =
        editSection(sectionUid) { s -> s.copy(items = s.items.map { if (it.uid == itemUid) f(it) else it }) }

    fun rename(name: String) = edit { it.copy(name = name.ifBlank { it.name }) }
    fun setNotes(n: String) = edit { it.copy(notes = n) }
    fun setIntensity(i: Intensity) = edit { it.copy(intensity = i) }

    fun addSection(type: SectionType) = edit { w ->
        val roundNo = w.sections.count { it.type == SectionType.ROUND } + 1
        val s = Section(
            type = type,
            title = when (type) { SectionType.ROUND -> "Round $roundNo"; else -> type.label },
            restAfterSec = if (type == SectionType.ROUND || type == SectionType.CONDITIONING) defaults.defaultRoundRestSec else 0
        )
        val list = w.sections.toMutableList()
        when (type) {
            SectionType.WARMUP -> list.add(0, s)
            SectionType.COOLDOWN -> list.add(s)
            else -> {
                val cd = list.indexOfFirst { it.type == SectionType.COOLDOWN }
                if (cd >= 0) list.add(cd, s) else list.add(s)
            }
        }
        w.copy(sections = list)
    }

    fun removeSection(uid: String) = edit { w -> w.copy(sections = w.sections.filterNot { it.uid == uid }) }
    fun duplicateSection(uid: String) = edit { w ->
        val i = w.sections.indexOfFirst { it.uid == uid }
        if (i < 0) w else {
            val src = w.sections[i]
            val copy = src.copy(uid = newUid(), title = src.title + " (copy)", items = src.items.map { it.copy(uid = newUid()) })
            w.copy(sections = w.sections.toMutableList().apply { add(i + 1, copy) })
        }
    }
    fun moveSection(uid: String, delta: Int) = edit { w ->
        val i = w.sections.indexOfFirst { it.uid == uid }; val j = i + delta
        if (i < 0 || j !in w.sections.indices) w
        else w.copy(sections = w.sections.toMutableList().apply { add(j, removeAt(i)) })
    }
    fun renameSection(uid: String, title: String) = editSection(uid) { it.copy(title = title.ifBlank { it.title }) }
    fun setSets(uid: String, sets: Int) = editSection(uid) { it.copy(sets = sets.coerceIn(1, 20)) }
    fun setSectionRest(uid: String, sec: Int) = editSection(uid) { it.copy(restAfterSec = sec.coerceIn(0, 600)) }

    /** Change a whole block's duration (used for warm-up / cooldown): spreads time evenly across items. */
    fun setSectionTotal(uid: String, totalSec: Int) = editSection(uid) { s ->
        if (s.items.isEmpty()) s else {
            val t = totalSec.coerceIn(s.items.size * 5, 3600)
            val each = t / s.items.size
            val extra = t - each * s.items.size
            s.copy(items = s.items.mapIndexed { i, item -> item.copy(seconds = each + if (i == s.items.lastIndex) extra else 0, restSec = 0) })
        }
    }

    fun addExercise(sectionUid: String, e: Exercise) = editSection(sectionUid) { s ->
        val rest = if (s.type == SectionType.WARMUP || s.type == SectionType.COOLDOWN) 0 else defaults.defaultRestSec
        val secs = if (s.type == SectionType.ROUND && e.defaultSeconds > 120) defaults.defaultWorkSec.coerceAtLeast(e.defaultSeconds) else e.defaultSeconds
        s.copy(items = s.items + e.toWorkItem(seconds = secs, restSec = rest))
    }
    fun removeItem(sectionUid: String, itemUid: String) =
        editSection(sectionUid) { s -> s.copy(items = s.items.filterNot { it.uid == itemUid }) }
    fun duplicateItem(sectionUid: String, itemUid: String) = editSection(sectionUid) { s ->
        val i = s.items.indexOfFirst { it.uid == itemUid }
        if (i < 0) s else s.copy(items = s.items.toMutableList().apply { add(i + 1, s.items[i].copy(uid = newUid())) })
    }
    fun replaceItem(sectionUid: String, itemUid: String, e: Exercise) =
        editItem(sectionUid, itemUid) { it.copy(exerciseId = e.id, name = e.name, category = e.category) }
    fun updateItem(sectionUid: String, itemUid: String, seconds: Int, reps: Int?, restSec: Int, note: String) =
        editItem(sectionUid, itemUid) {
            it.copy(seconds = seconds.coerceIn(5, 3600), reps = reps?.takeIf { r -> r > 0 }, restSec = restSec.coerceIn(0, 600), note = note)
        }

    /** Move an item up/down; crosses into the neighbouring section at the edges. */
    fun moveItem(sectionUid: String, itemUid: String, delta: Int) = edit { w ->
        val si = w.sections.indexOfFirst { it.uid == sectionUid }
        if (si < 0) return@edit w
        val s = w.sections[si]
        val ii = s.items.indexOfFirst { it.uid == itemUid }
        if (ii < 0) return@edit w
        val target = ii + delta
        val list = w.sections.toMutableList()
        if (target in s.items.indices) {
            list[si] = s.copy(items = s.items.toMutableList().apply { add(target, removeAt(ii)) })
        } else {
            val nsi = si + delta
            if (nsi !in list.indices) return@edit w
            val item = s.items[ii]
            list[si] = s.copy(items = s.items.filterIndexed { i, _ -> i != ii })
            val ns = list[nsi]
            list[nsi] = ns.copy(items = if (delta < 0) ns.items + item else listOf(item) + ns.items)
        }
        w.copy(sections = list)
    }

    fun applyWorkToAll(sec: Int) = edit { w ->
        w.copy(sections = w.sections.map { s ->
            if (s.type == SectionType.ROUND || s.type == SectionType.CONDITIONING) s.copy(items = s.items.map { it.copy(seconds = sec) }) else s
        })
    }
    fun applyRestToAll(sec: Int) = edit { w ->
        w.copy(sections = w.sections.map { s ->
            if (s.type == SectionType.ROUND || s.type == SectionType.CONDITIONING)
                s.copy(items = s.items.mapIndexed { i, item -> item.copy(restSec = if (i == s.items.lastIndex) 0 else sec) })
            else s
        })
    }

    fun save(onSaved: (Workout) -> Unit = {}) {
        val w = _w.value ?: return
        viewModelScope.launch {
            val id = c.repo.saveWorkout(w)
            val saved = w.copy(id = id)
            _w.value = saved; _dirty.value = false
            c.draft = null
            onSaved(saved)
        }
    }

    fun start(): Boolean {
        val w = _w.value ?: return false
        if (w.sections.all { it.items.isEmpty() }) return false
        c.session.start(w)
        return true
    }
}
