package com.roundbell.muaythai.domain

import com.roundbell.muaythai.data.model.Category
import com.roundbell.muaythai.data.model.Difficulty
import com.roundbell.muaythai.data.model.Equipment
import com.roundbell.muaythai.data.model.Exercise
import com.roundbell.muaythai.data.model.Goal
import com.roundbell.muaythai.data.model.Intensity
import com.roundbell.muaythai.data.model.Section
import com.roundbell.muaythai.data.model.SectionType
import com.roundbell.muaythai.data.model.TrainingStyle
import com.roundbell.muaythai.data.model.WorkItem
import com.roundbell.muaythai.data.model.Workout
import com.roundbell.muaythai.data.seed.ExerciseSeed
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.random.Random

data class GeneratorParams(
    val goal: Goal = Goal.GENERAL,
    val difficulty: Difficulty = Difficulty.BEGINNER,
    val minutes: Int = 20,
    val style: TrainingStyle = TrainingStyle.MIXED,
    val equipment: Set<Equipment> = setOf(Equipment.NONE),
    val intensity: Intensity = Intensity.MODERATE
)

/**
 * Rule-based generator: warm-up → technique rounds → optional conditioning circuit → cooldown.
 * Work/rest ratios depend on goal, difficulty and intensity; exercise choice depends on
 * style, difficulty and available equipment.
 */
object WorkoutGenerator {

    private data class Pattern(val work: Int, val rest: Int, val perRound: Int, val roundRest: Int)

    private val roundFocus = mapOf(
        TrainingStyle.BOXING to listOf("Jab-cross and hooks", "Body-head combinations", "Defence then counter", "Feints and footwork"),
        TrainingStyle.KICKS to listOf("Round kicks both sides", "Teeps to stop pressure", "Low kick combinations", "Punch-to-kick finishes"),
        TrainingStyle.KNEES to listOf("Straight knees", "Switch knees", "Knees off the teep", "Clinch knees"),
        TrainingStyle.ELBOWS to listOf("Horizontal and diagonal elbows", "Punches into elbows", "Close-range pocket work"),
        TrainingStyle.CLINCH to listOf("Pummel and knee", "Turns and off-balances", "Posture battles"),
        TrainingStyle.DEFENSE to listOf("Check and counter", "Parry and return", "Pull back and teep", "Angles off the line"),
        TrainingStyle.FOOTWORK to listOf("Angles and pivots", "In-and-out movement", "Circling the ring"),
        TrainingStyle.FULL to listOf("All weapons flowing", "End every combo with a kick", "Knees and elbows in close", "Counter-attack round", "Pressure round"),
        TrainingStyle.CONDITIONING to listOf("Continuous output", "Burst every 20 seconds", "Steady pace"),
        TrainingStyle.MIXED to listOf("Technical round", "Power round", "Speed round", "Defence round", "Pressure round")
    )

    fun categoriesFor(style: TrainingStyle): List<Category> = when (style) {
        TrainingStyle.BOXING -> listOf(Category.BOXING, Category.BOXING, Category.DEFENSE, Category.FOOTWORK)
        TrainingStyle.KICKS -> listOf(Category.KICKS, Category.KICKS, Category.FOOTWORK, Category.DEFENSE)
        TrainingStyle.KNEES -> listOf(Category.KNEES, Category.KNEES, Category.CLINCH)
        TrainingStyle.ELBOWS -> listOf(Category.ELBOWS, Category.ELBOWS, Category.BOXING)
        TrainingStyle.CLINCH -> listOf(Category.CLINCH, Category.KNEES, Category.CLINCH)
        TrainingStyle.DEFENSE -> listOf(Category.DEFENSE, Category.DEFENSE, Category.FOOTWORK, Category.BOXING)
        TrainingStyle.FOOTWORK -> listOf(Category.FOOTWORK, Category.FOOTWORK, Category.DEFENSE)
        TrainingStyle.FULL -> listOf(Category.BOXING, Category.KICKS, Category.KNEES, Category.ELBOWS, Category.DEFENSE)
        TrainingStyle.CONDITIONING -> listOf(Category.CONDITIONING)
        TrainingStyle.MIXED -> listOf(Category.BOXING, Category.KICKS, Category.KNEES, Category.DEFENSE, Category.CONDITIONING)
    }

    private fun pattern(p: GeneratorParams): Pattern {
        val base = when (p.goal) {
            Goal.TECHNIQUE -> Pattern(45, 15, 4, 45)
            Goal.CARDIO -> Pattern(40, 15, 4, 45)
            Goal.CONDITIONING -> Pattern(45, 15, 4, 60)
            Goal.SPEED -> Pattern(20, 10, 5, 40)
            Goal.POWER -> Pattern(30, 30, 3, 60)
            Goal.FAT_LOSS -> Pattern(40, 20, 4, 40)
            Goal.ENDURANCE -> Pattern(60, 10, 3, 45)
            Goal.GENERAL -> Pattern(40, 20, 4, 45)
            Goal.SHADOWBOXING, Goal.FIGHT_PREP -> Pattern(180, 0, 1, 60)
        }
        val workMul = when (p.difficulty) { Difficulty.BEGINNER -> 0.8; Difficulty.INTERMEDIATE -> 1.0; Difficulty.ADVANCED -> 1.15 }
        val restMul = when (p.difficulty) { Difficulty.BEGINNER -> 1.4; Difficulty.INTERMEDIATE -> 1.0; Difficulty.ADVANCED -> 0.75 } *
            when (p.intensity) { Intensity.EASY -> 1.3; Intensity.MODERATE -> 1.0; Intensity.HARD -> 0.85; Intensity.MAXIMUM -> 0.7 }
        val isRoundBased = p.goal == Goal.SHADOWBOXING || p.goal == Goal.FIGHT_PREP
        val work = if (isRoundBased) {
            when (p.difficulty) { Difficulty.BEGINNER -> 120; Difficulty.INTERMEDIATE -> 180; Difficulty.ADVANCED -> 180 }
        } else r5(base.work * workMul).coerceAtLeast(15)
        val roundRest = if (isRoundBased) {
            when (p.difficulty) { Difficulty.BEGINNER -> 60; Difficulty.INTERMEDIATE -> 60; Difficulty.ADVANCED -> 45 }
        } else r5(base.roundRest * restMul).coerceAtLeast(15)
        return Pattern(work, if (base.rest == 0) 0 else r5(base.rest * restMul).coerceAtLeast(5), base.perRound, roundRest)
    }

    private fun conditioningShare(p: GeneratorParams): Double {
        if (p.minutes <= 6 || p.style == TrainingStyle.CONDITIONING) return 0.0
        return when (p.goal) {
            Goal.CONDITIONING -> 0.4; Goal.FAT_LOSS -> 0.35; Goal.CARDIO -> 0.3; Goal.ENDURANCE -> 0.25
            Goal.POWER -> 0.25; Goal.GENERAL -> 0.2; Goal.FIGHT_PREP -> 0.2; Goal.SPEED -> 0.15
            Goal.TECHNIQUE, Goal.SHADOWBOXING -> 0.0
        }
    }

    private fun r5(v: Double): Int = ((v / 5.0).roundToInt() * 5)
    private fun r5(v: Int): Int = r5(v.toDouble())

    /** Rotating picker that avoids repeats until a category is exhausted. */
    private class Picker(pool: List<Exercise>, private val rnd: Random) {
        private val byCat = pool.groupBy { it.category }.mapValues { it.value.shuffled(rnd).toMutableList() }
        private val used = mutableMapOf<Category, MutableList<Exercise>>()
        private val all = pool

        fun pick(cat: Category, prefer: (Exercise) -> Boolean = { true }): Exercise? {
            val remaining = byCat[cat]
            if (remaining.isNullOrEmpty()) {
                val u = used[cat]
                if (!u.isNullOrEmpty()) {
                    byCat[cat]?.addAll(u.shuffled(rnd)); u.clear()
                    return pick(cat, prefer)
                }
                return all.filter { it.category != Category.MOBILITY && it.category != Category.CONDITIONING }
                    .randomOrNull(rnd)
            }
            val choice = remaining.firstOrNull(prefer) ?: remaining.first()
            remaining.remove(choice)
            used.getOrPut(cat) { mutableListOf() }.add(choice)
            return choice
        }
    }

    fun generate(p: GeneratorParams, library: List<Exercise>, seed: Long = System.nanoTime()): Workout {
        val rnd = Random(seed)
        val total = p.minutes.coerceIn(3, 180) * 60
        val eq = p.equipment + Equipment.NONE
        val pool = library.filter { ex ->
            !ex.isCustom && ex.difficulty.ordinal <= p.difficulty.ordinal && ex.equipment.all { it in eq }
        }
        val picker = Picker(pool, rnd)
        val pat = pattern(p)

        val warm = if (total <= 360) 60 else r5(total * 0.12).coerceIn(120, 420)
        val cool = if (total <= 360) 30 else r5(total * 0.08).coerceIn(60, 300)
        val main = (total - warm - cool).coerceAtLeast(60)
        val condTime = (main * conditioningShare(p)).toInt()
        val techTime = main - condTime

        val sections = mutableListOf<Section>()
        sections += warmup(warm, pool, eq, rnd)
        sections += technicalRounds(p, pat, techTime, picker, pool, eq)
        if (condTime >= 90) conditioning(p, pat, condTime, picker, pool)?.let { sections += it }
        sections += cooldown(cool, pool, rnd)

        var w = Workout(
            name = "${p.style.label} · ${p.goal.label} · ${p.minutes} min",
            goal = p.goal, difficulty = p.difficulty, intensity = p.intensity, style = p.style,
            sections = sections,
            notes = "Generated for ${p.difficulty.label.lowercase()} level, ${p.intensity.label.lowercase()} intensity."
        )
        // Absorb rounding differences in the warm-up so the total lands close to the target.
        val diff = total - WorkoutMath.summary(w, 70.0).totalSec
        if (diff != 0 && w.sections.first().items.isNotEmpty()) {
            val ws = w.sections.first()
            val last = ws.items.last()
            val newSec = (last.seconds + diff).coerceIn(15, 600)
            w = w.copy(sections = listOf(ws.copy(items = ws.items.dropLast(1) + last.copy(seconds = newSec))) + w.sections.drop(1))
        }
        return w
    }

    private fun warmup(seconds: Int, pool: List<Exercise>, eq: Set<Equipment>, rnd: Random): Section {
        val items = mutableListOf<WorkItem>()
        var left = seconds
        val rope = pool.firstOrNull { it.id == "jump_rope" }
        if (rope != null && Equipment.JUMP_ROPE in eq && left >= 150) {
            items += WorkItem(exerciseId = rope.id, name = rope.name, category = rope.category, seconds = 60); left -= 60
        }
        val mob = pool.filter { it.category == Category.MOBILITY && it.id !in ExerciseSeed.cooldownIds && it.id != "light_shadowboxing" }
            .shuffled(rnd)
        val light = pool.firstOrNull { it.id == "light_shadowboxing" }
        val reserve = if (light != null && seconds >= 180) 60 else 0
        for (m in mob) {
            if (left - reserve < 30) break
            items += WorkItem(exerciseId = m.id, name = m.name, category = m.category, seconds = 30); left -= 30
        }
        if (light != null && left >= 30) {
            items += WorkItem(exerciseId = light.id, name = light.name, category = light.category, seconds = left); left = 0
        }
        if (items.isEmpty()) items += WorkItem(exerciseId = "light_shadowboxing", name = "Light shadowboxing", category = Category.MOBILITY, seconds = seconds)
        else if (left > 0) items[items.lastIndex] = items.last().let { it.copy(seconds = it.seconds + left) }
        return Section(type = SectionType.WARMUP, title = "Warm-up", items = items)
    }

    private fun cooldown(seconds: Int, pool: List<Exercise>, rnd: Random): Section {
        val stretches = pool.filter { it.id in ExerciseSeed.cooldownIds && it.id != "breathing_recovery" }.shuffled(rnd)
        val breathe = pool.firstOrNull { it.id == "breathing_recovery" }
        val items = mutableListOf<WorkItem>()
        var left = seconds
        for (s in stretches) {
            if (left < (if (breathe != null) 60 else 30)) break
            items += WorkItem(exerciseId = s.id, name = s.name, category = s.category, seconds = 30); left -= 30
        }
        if (breathe != null && left > 0) items += WorkItem(exerciseId = breathe.id, name = breathe.name, category = breathe.category, seconds = left)
        else if (items.isNotEmpty() && left > 0) items[items.lastIndex] = items.last().let { it.copy(seconds = it.seconds + left) }
        return Section(type = SectionType.COOLDOWN, title = "Cooldown", items = items)
    }

    private fun technicalRounds(
        p: GeneratorParams, pat: Pattern, time: Int, picker: Picker, pool: List<Exercise>, eq: Set<Equipment>
    ): List<Section> {
        val focus = roundFocus[p.style].orEmpty()
        val bag = Equipment.HEAVY_BAG in eq
        val mitts = Equipment.MITTS in eq

        if (p.goal == Goal.SHADOWBOXING || p.goal == Goal.FIGHT_PREP) {
            val roundLen = pat.work + pat.roundRest
            val rounds = max(1, ((time + pat.roundRest) / roundLen.toDouble()).roundToInt())
            val workSec = if (rounds == 1) (time).coerceAtMost(pat.work * 2).coerceAtLeast(60) else pat.work
            return (1..rounds).map { r ->
                val (exId, exName) = when {
                    p.goal == Goal.FIGHT_PREP && bag && r % 2 == 1 -> "heavy_bag_round" to "Heavy bag round"
                    p.goal == Goal.FIGHT_PREP && mitts && r % 2 == 0 -> "mitt_round" to "Focus mitt round"
                    else -> "shadowboxing" to "Shadowboxing"
                }
                val f = if (focus.isEmpty()) "" else "Focus: " + focus[(r - 1) % focus.size]
                val pace = if (p.goal == Goal.FIGHT_PREP) " · fight pace" else ""
                Section(
                    type = SectionType.ROUND, title = "Round $r",
                    items = listOf(WorkItem(exerciseId = exId, name = exName, category = Category.CONDITIONING, seconds = workSec, note = f + pace)),
                    restAfterSec = if (r < rounds) pat.roundRest else 0
                )
            }
        }

        val cats = categoriesFor(p.style)
        val roundLen = pat.perRound * pat.work + (pat.perRound - 1) * pat.rest + pat.roundRest
        val rounds = max(1, ((time + pat.roundRest) / roundLen.toDouble()).roundToInt())
        var catIdx = 0
        return (1..rounds).map { r ->
            val items = (0 until pat.perRound).mapNotNull { i ->
                val cat = cats[catIdx++ % cats.size]
                val prefer: (Exercise) -> Boolean = when (p.goal) {
                    Goal.POWER -> ({ e: Exercise -> e.name.contains("Rear", true) || e.name.contains("Jump", true) || e.id.contains("kick") })
                    Goal.SPEED -> ({ e: Exercise -> e.difficulty != Difficulty.ADVANCED })
                    else -> ({ _: Exercise -> true })
                }
                picker.pick(cat, prefer)?.let { ex ->
                    val striking = ex.category in setOf(Category.BOXING, Category.KICKS, Category.KNEES, Category.ELBOWS)
                    val note = when {
                        striking && bag -> "On the heavy bag"
                        striking && mitts -> "On mitts with a partner"
                        else -> ""
                    }
                    WorkItem(exerciseId = ex.id, name = ex.name, category = ex.category, seconds = pat.work,
                        reps = null, restSec = if (i < pat.perRound - 1) pat.rest else 0, note = note)
                }
            }
            Section(
                type = SectionType.ROUND,
                title = if (focus.isNotEmpty()) "Round $r · ${focus[(r - 1) % focus.size]}" else "Round $r",
                items = items,
                restAfterSec = if (r < rounds) pat.roundRest else 0
            )
        }
    }

    private fun conditioning(p: GeneratorParams, pat: Pattern, time: Int, picker: Picker, pool: List<Exercise>): Section? {
        val work = when (p.goal) { Goal.POWER -> 25; Goal.ENDURANCE -> 50; else -> 40 }.let {
            when (p.difficulty) { Difficulty.BEGINNER -> it - 10; Difficulty.INTERMEDIATE -> it; Difficulty.ADVANCED -> it + 5 }
        }
        val rest = when (p.intensity) { Intensity.EASY -> 25; Intensity.MODERATE -> 20; Intensity.HARD -> 15; Intensity.MAXIMUM -> 10 }
        val perCircuit = if (time < 300) 3 else 4
        val circuitRest = 45
        val prefer: (Exercise) -> Boolean = when (p.goal) {
            Goal.POWER -> ({ e: Exercise -> e.id in setOf("squat_jumps", "skater_jumps", "burpees", "sprawls", "kettlebell_swing") })
            else -> ({ e: Exercise -> e.defaultSeconds <= 60 })
        }
        val items = (0 until perCircuit).mapNotNull { i ->
            picker.pick(Category.CONDITIONING) { e -> prefer(e) && e.defaultSeconds <= 60 }?.let { ex ->
                val sec = work
                WorkItem(exerciseId = ex.id, name = ex.name, category = ex.category, seconds = sec,
                    restSec = if (i < perCircuit - 1) rest else 0)
            }
        }.distinctBy { it.exerciseId }
        if (items.isEmpty()) return null
        val circuitLen = items.sumOf { it.seconds + it.restSec } + circuitRest
        val sets = max(1, ((time + circuitRest) / circuitLen.toDouble()).roundToInt())
        return Section(type = SectionType.CONDITIONING, title = "Conditioning circuit", items = items,
            sets = sets, restAfterSec = circuitRest)
    }
}
