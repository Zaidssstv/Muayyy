package com.roundbell.muaythai.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.roundbell.muaythai.R
import com.roundbell.muaythai.domain.formatClock
import com.roundbell.muaythai.domain.formatMinutes
import com.roundbell.muaythai.player.PlayerUi
import com.roundbell.muaythai.player.PlayerViewModel
import com.roundbell.muaythai.ui.Nav
import com.roundbell.muaythai.ui.components.StatRow
import com.roundbell.muaythai.ui.components.StatTile
import com.roundbell.muaythai.ui.theme.Gold
import com.roundbell.muaythai.ui.theme.RestGreen
import com.roundbell.muaythai.ui.theme.TimerStyle

@Composable
fun PlayerScreen(pvm: PlayerViewModel, nav: Nav) {
    val ui by pvm.ui.collectAsStateWithLifecycle()
    var confirmEnd by rememberSaveable { mutableStateOf(false) }

    // Keep the display awake while a session is on screen (user setting).
    val view = LocalView.current
    DisposableEffect(ui.keepScreenOn, ui.finished) {
        view.keepScreenOn = ui.keepScreenOn && !ui.finished
        onDispose { view.keepScreenOn = false }
    }
    // Back = leave the player; the session stays saved (paused) and can be continued from Home.
    BackHandler(enabled = !ui.finished) {
        if (ui.running) pvm.togglePause()
        nav.back()
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).safeDrawingPadding()) {
        when {
            !ui.loaded -> Text("Loading…", Modifier.align(Alignment.Center))
            ui.missing -> Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("No workout in progress", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text("Start a workout from Home, Workouts or the generator.", textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { nav.back() }) { Text("Go back") }
            }
            ui.finished -> FinishedView(ui, onDone = { nav.back() }, onDetails = { id -> nav.playerToHistory(id) })
            else -> ActiveView(ui, pvm, onEnd = { if (ui.running) pvm.togglePause(); confirmEnd = true }, onMinimize = {
                if (ui.running) pvm.togglePause(); nav.back()
            })
        }
    }

    if (confirmEnd) AlertDialog(
        onDismissRequest = { confirmEnd = false },
        title = { Text("End workout?") },
        text = { Text("Save what you've done so far to your history, or discard this session.") },
        confirmButton = { TextButton(onClick = { confirmEnd = false; pvm.end(save = true) }) { Text("Save & end") } },
        dismissButton = {
            Row {
                TextButton(onClick = { confirmEnd = false; pvm.end(save = false); nav.back() }) {
                    Text("Discard", color = MaterialTheme.colorScheme.error)
                }
                TextButton(onClick = { confirmEnd = false }) { Text("Keep going") }
            }
        }
    )
}

@Composable
private fun ActiveView(ui: PlayerUi, pvm: PlayerViewModel, onEnd: () -> Unit, onMinimize: () -> Unit) {
    val step = ui.step ?: return
    val isPrep = step.exerciseId == PlayerUi.GET_READY
    val accent = when {
        isPrep -> Gold
        step.isRest -> RestGreen
        else -> MaterialTheme.colorScheme.primary
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val landscape = maxWidth > maxHeight
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            // Top bar
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onMinimize) { Icon(painterResource(R.drawable.ic_pause), "Pause and leave player") }
                Text(ui.workoutName, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                IconButton(onClick = onEnd) { Icon(Icons.Default.Close, "End workout") }
            }
            LinearProgressIndicator(
                progress = { ui.workoutProgress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape)
                    .semantics { contentDescription = "Workout ${(ui.workoutProgress * 100).toInt()} percent complete" },
            )
            Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                Text("Elapsed ${formatClock((ui.elapsedMs / 1000).toInt())}", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                Text("Remaining ${formatClock(((ui.remainingWorkoutMs + 999) / 1000).toInt())}", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            if (landscape) {
                Row(Modifier.weight(1f).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) { MainInfo(ui, accent, isPrep, compact = true) }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        NextInfo(ui); Spacer(Modifier.height(12.dp)); Controls(ui, pvm)
                    }
                }
            } else {
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    MainInfo(ui, accent, isPrep, compact = false)
                    Spacer(Modifier.height(20.dp))
                    NextInfo(ui)
                }
                Controls(ui, pvm)
            }
        }
    }
}

@Composable
private fun ColumnScope.MainInfo(ui: PlayerUi, accent: Color, isPrep: Boolean, compact: Boolean) {
    val step = ui.step ?: return
    val sec = ((ui.remainingMs.coerceAtLeast(0) + 999) / 1000).toInt()
    val label = when { isPrep -> "GET READY"; step.isRest -> "REST"; else -> step.label.uppercase() }
    val context = when {
        isPrep || step.isRest -> ""
        ui.currentRound > 0 && ui.totalRounds > 0 -> "ROUND ${ui.currentRound} / ${ui.totalRounds}"
        else -> step.sectionTitle.uppercase()
    }
    if (!step.isRest) Text("Exercise ${ui.exerciseNumber} of ${ui.exerciseCount}", style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(label, style = MaterialTheme.typography.headlineLarge.copy(fontSize = if (compact) 30.sp else 38.sp),
        fontWeight = FontWeight.Black, color = accent, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
    step.reps?.let { Text("$it reps", style = MaterialTheme.typography.titleMedium) }
    Text(
        formatClock(sec),
        style = if (compact) TimerStyle.copy(fontSize = 72.sp) else TimerStyle,
        modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite; contentDescription = "$sec seconds left" }
    )
    LinearProgressIndicator(
        progress = { ui.stepProgress }, color = accent,
        modifier = Modifier.fillMaxWidth(0.8f).height(10.dp).clip(CircleShape)
    )
    if (context.isNotEmpty()) {
        Spacer(Modifier.height(10.dp))
        Text(context, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
    if (step.note.isNotBlank()) {
        Spacer(Modifier.height(6.dp))
        Text(step.note, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary, textAlign = TextAlign.Center)
    }
    if (!ui.running) {
        Spacer(Modifier.height(8.dp))
        Text("PAUSED", style = MaterialTheme.typography.labelLarge, color = Gold, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NextInfo(ui: PlayerUi) {
    val next = ui.nextExercise
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("NEXT", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(next?.label?.uppercase() ?: "FINISH", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, maxLines = 2)
        if (next != null) Text(formatClock(next.seconds), style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun Controls(ui: PlayerUi, pvm: PlayerViewModel) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically) {
        FilledTonalIconButton(onClick = { pvm.previous() }, modifier = Modifier.size(72.dp)) {
            Icon(painterResource(R.drawable.ic_skip_previous), "Previous or restart exercise", Modifier.size(36.dp))
        }
        FilledIconButton(
            onClick = { pvm.togglePause() }, modifier = Modifier.size(104.dp),
            colors = IconButtonDefaults.filledIconButtonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            if (ui.running) Icon(painterResource(R.drawable.ic_pause), "Pause", Modifier.size(52.dp))
            else Icon(Icons.Default.PlayArrow, "Resume", Modifier.size(56.dp))
        }
        FilledTonalIconButton(onClick = { pvm.skip() }, modifier = Modifier.size(72.dp)) {
            Icon(painterResource(R.drawable.ic_skip_next), "Skip to next", Modifier.size(36.dp))
        }
    }
}

@Composable
private fun FinishedView(ui: PlayerUi, onDone: () -> Unit, onDetails: (Long) -> Unit) {
    val r = ui.result
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(140.dp), tint = Color.Unspecified)
        Text(if (r != null && r.completionPct >= 100) "WORKOUT COMPLETE" else "SESSION ENDED",
            style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
        Text(ui.workoutName, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        if (r != null) {
            StatRow {
                StatTile(formatMinutes(r.durationSec), "Time", Modifier.weight(1f))
                StatTile("${r.roundsCompleted}/${r.totalRounds}", "Rounds", Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            StatRow {
                StatTile("~${r.calories}", "kcal (est.)", Modifier.weight(1f))
                StatTile("${r.completionPct}%", "Completed", Modifier.weight(1f))
            }
            Spacer(Modifier.height(24.dp))
            Button(onClick = { onDetails(r.id) }, Modifier.fillMaxWidth().height(56.dp), enabled = r.id > 0) { Text("VIEW DETAILS") }
            Spacer(Modifier.height(8.dp))
        } else {
            Text("Nothing was recorded for this session.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
        }
        OutlinedButton(onClick = onDone, Modifier.fillMaxWidth().height(56.dp)) { Text("DONE") }
        Spacer(Modifier.width(1.dp))
    }
}
