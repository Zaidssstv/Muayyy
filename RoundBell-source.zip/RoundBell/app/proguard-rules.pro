# Minification is disabled by default. Rules kept here for future use.
-keep class com.roundbell.muaythai.data.** { *; }
