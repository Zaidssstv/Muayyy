# RoundBell — Muay Thai Trainer (Android)

Offline Muay Thai workout app: Kotlin · Jetpack Compose · Material 3 · Room · DataStore.
Package `com.roundbell.muaythai` · version 1.0.0 (code 1) · minSdk 26 · targetSdk 34.

## Build the APK

### Option A — GitHub Actions (works from a phone, no PC needed)
1. Create a new GitHub repository and upload the contents of this folder
   (the folder that contains `settings.gradle.kts`, including the hidden `.github` folder).
2. Open the **Actions** tab → **Build APK** → **Run workflow** (it also runs on every push).
3. When it finishes (~5–10 min) open the run and download the **RoundBell-release-apk** artifact.
   Unzip it and install `app-release.apk` (allow "Install unknown apps" for your browser/file manager).

### Option B — Android Studio (Koala / Ladybug or newer)
1. File → Open → select this folder. Let Gradle sync (it downloads Gradle 8.9 and dependencies).
2. Build → Build App Bundle(s) / APK(s) → Build APK(s), or run `gradle assembleRelease`.
3. Output: `app/build/outputs/apk/release/app-release.apk`.

No `gradlew` jar is included (it could not be generated offline). If you want the wrapper,
run `gradle wrapper --gradle-version 8.9` once with a local Gradle install.

### Signing
Without extra setup, the release APK is signed with the standard Android debug key so it
installs directly on phones. For your own key, create `keystore.properties` in the project root:

```
storeFile=release.jks
storePassword=...
keyAlias=...
keyPassword=...
```

## Tests
`gradle testDebugUnitTest` — covers workout flattening/summary math, the generator
(duration and equipment constraints across all goals/styles), JSON share codec, and stats/streaks.

## Architecture
UI (Compose screens) → ViewModels (`AppViewModel`, `BuilderViewModel`, `PlayerViewModel`)
→ `TrainingRepository` → Room (exercises, workouts, history) / DataStore (settings, profile).
The active workout session is snapshotted to SharedPreferences every second so it survives
backgrounding and process death. `Exercise.mediaUri` is reserved for future video/animation assets.
